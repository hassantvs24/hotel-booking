<?php

namespace App\Http\Controllers\API\Admin\Property;

use App\Http\Controllers\BaseController;
use App\Http\Requests\Admin\Property\PropertyRequest;
use App\Models\Facility;
use App\Models\Property;
use App\Models\PropertyCategory;
use App\Models\PropertyRule;
use App\Models\User;
use App\Repositories\Admin\PropertyRepository;
use App\Traits\MediaMan;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Throwable;

class PropertyController extends BaseController
{
    use MediaMan;

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request, PropertyRepository $propertyRepository): JsonResponse
    {

        $query = [
            'with'     => ['user'],
            'where'    => [],
            'order_by' => 'id',
            'order'    => 'DESC',
            'per_page' => (int) $request->input('per_page', 15),
            'page'     => (int) $request->input('page', 1),
            'search'   => (string) $request->input('search', ''),
            'filters'  => array_filter([
                'status' => $request->input('status'),
            ]),
        ];

        $properties = $propertyRepository->paginate($query);


        $data = [
            'properties' => $properties,
        ];

        return $this->sendSuccess($data);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(PropertyRequest $request, PropertyRepository $propertyRepository): JsonResponse
    {

        DB::beginTransaction();
        try {
            $checkInTime = Carbon::parse($request->input('check_in_time'))->format('H:i:s');
            $checkOutTime = Carbon::parse($request->input('check_out_time'))->format('H:i:s');

            $data = array_merge(
                $request->except(['primaryImage', 'facility_sub_ids', 'rules', 'additionalImages']),
                [
                    'user_id' => $request->user()->id,
                    'check_in_time' => $checkInTime,
                    'check_out_time' => $checkOutTime
                ]
            );

            $property = $propertyRepository->create($data);
            if (is_array($request->input('facility_sub_ids'))) {
                $property->facilities()->attach($request->input('facility_sub_ids'));
            }

            if ($request->hasFile('primaryImage')) {
                $image = $this->storeFile($request->file('primaryImage'), 'properties');
                $property->primaryImage()->create([...$image, 'media_role' => 'property_image']);
            }
            if ($request->hasFile('additionalImages')) {
                foreach ($request->file('additionalImages') as $file) {
                    $galleryImage = $this->storeFile($file, 'properties');
                    $property->images()->create(array_merge($galleryImage, ['media_role' => 'property_gallery_image']));
                }
            }

            if ($request->input('rules')) {
                $rules = $request->input('rules');
                foreach ($rules as $rule) {
                    $isActive =  $rule['is_active'] === true ? 1 : 0;

                    $property->rules()->updateOrCreate(
                        ['property_rule_id' => $rule['property_rule_id']],
                        [
                            'rule_description' => $rule['description'],
                            'is_active' => $isActive,
                        ]
                    );
                }
            }


            DB::commit();

            return $this->sendSuccess($property->load('facilities', 'primaryImage'));
        } catch (Exception $e) {
            DB::rollBack();
            return $this->sendError($e->getMessage());
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(
        PropertyRequest    $request,
        PropertyRepository $propertyRepository,
        $property
    ): JsonResponse {

        DB::beginTransaction();
        try {
            // Format check-in and check-out time
            $checkInTime = Carbon::parse($request->input('check_in_time'))->format('H:i:s');
            $checkOutTime = Carbon::parse($request->input('check_out_time'))->format('H:i:s');

            // Merge request data
            $data = array_merge(
                $request->except(['primaryImage', 'facility_sub_ids', 'rules', 'additionalImages']),
                [
                    'user_id' => $request->user()->id,
                    'check_in_time' => $checkInTime,
                    'check_out_time' => $checkOutTime,
                ]
            );

            $propertyRepository->update($data);

            if (is_array($request->input('facility_sub_ids'))) {
                $property->facilities()->sync($request->input('facility_sub_ids'));
            }

            if ($request->hasFile('primaryImage')) {
                $this->deletePrimaryImage($property);
                $image = $this->storeFile($request->file('primaryImage'), 'properties');
                $property->primaryImage()->create(array_merge($image, ['media_role' => 'property_image']));
            }

            if ($request->hasFile('additionalImages')) {
                $this->deleteAdditionalImage($property);
                foreach ($request->file('additionalImages') as $file) {
                    $galleryImage = $this->storeFile($file, 'properties');
                    $property->images()->create(array_merge($galleryImage, ['media_role' => 'property_gallery_image']));
                }
            }

            if ($request->input('rules')) {
                $rules = $request->input('rules');
                foreach ($rules as $rule) {
                    $isActive = $rule['is_active'] === true ? 1 : 0;

                    $property->rules()->updateOrCreate(
                        ['property_rule_id' => $rule['property_rule_id']],
                        [
                            'rule_description' => $rule['description'],
                            'is_active' => $isActive,
                        ]
                    );
                }
            }
            DB::commit();

            return $this->sendSuccess($property->load('facilities', 'primaryImage', 'images', 'rules'));
        } catch (Exception $e) {
            DB::rollBack();
            return $this->sendError('Failed to update property: ' . $e->getMessage());
        }
    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(PropertyRepository $propertyRepository, $property): JsonResponse
    {
        try {
            $property = $propertyRepository->getModel($property);
            $this->deleteImage($property);
            $propertyRepository->delete($property->id);

            return $this->sendSuccess([], 'Property deleted successfully');
        } catch (Exception $e) {
            return $this->sendError($e->getMessage());
        }
    }

    public function all(PropertyRepository $propertyRepository): JsonResponse
    {
        $properties = $propertyRepository->get();

        $data = [
            'properties' => $properties
        ];

        return $this->sendSuccess($data);
    }

    private function deleteImage($property): void
    {
        if ($property->primaryImage()->exists()) {
            $this->deleteFile($property->primaryImage->name, 'properties');
            $property->primaryImage()->delete();
        }
    }

    public function propertyAction(Property $property, Request $request): JsonResponse
    {
        $originalStatus = $property->status;
        $statusInput = $request->input('status');

        DB::beginTransaction();
        try {

            if ($originalStatus === $statusInput) {
                return $this->sendSuccess($property, 'Property status updated successfully');
            }

            $property->update([
                'status' => $statusInput
            ]);

            $propertyOwnerRoleName = config('site.hotelOwnerGroup');
            $propertyOwner = User::query()->where('id', $property->user_id)->first();
            $propertyOwnerRole = Role::query()->where('name', $propertyOwnerRoleName)->first();


            if ($statusInput === 'Published') {

                $existingRoles = $propertyOwner->roles()->whereNotNull('property_id')->get();

                if ($existingRoles->isNotEmpty()) {
                    foreach ($existingRoles as $role) {
                        $propertyOwner->removeRole($role);
                    }
                }

                if ($propertyOwnerRole) {
                    $propertyOwner->assignRole($propertyOwnerRole);
                }
            } else if ($statusInput === 'Unpublished') {
                if (!$propertyOwner->isAdmin) {
                    $propertyOwner->removeRole($propertyOwnerRoleName);
                }
            }

            DB::commit();
            return $this->sendSuccess($property, 'Property status updated successfully');
        } catch (Throwable $e) {
            DB::rollBack();
            return $this->sendError($e->getMessage());
        }
    }

    public function propertyAttributes(): JsonResponse
    {
        $categories = PropertyCategory::query()->get(['id', 'name']);
        $facilities = Facility::with([
            'subFacilities' => function ($query) {
                $query->select('id', 'name', 'facility_id');
            }
        ])
            ->whereHas('subFacilities')
            ->where('facility_for', 'Property')
            ->get(['id', 'name']);

        $propertyRules = PropertyRule::query()->get();

        $data = [
            'categories' => $categories,
            'facilities' => $facilities,
            'property_rules' => $propertyRules
        ];

        return $this->sendSuccess($data);
    }

    public function details(Property $property): JsonResponse
    {
        $property->load([
            'primaryImage',
            'images',
            'logoImage',
            'facilities',
            'facilities.facility',
            'rules.propertyRule',
            'rooms',
            'propertyCategory',
            'place',
            'user',
            'staffs',
            'reviews'
        ]);

        return $this->sendSuccess($property);
    }

    /**
     * Delete the primary image of the property
     *
     * @param Property $property
     * @return void
     */
    private function deletePrimaryImage(Property $property): void
    {
        if ($property->primaryImage()->exists()) {
            $primaryImage = $property->primaryImage()->first();
            $this->deleteFile($primaryImage->name, 'properties');
            $primaryImage->delete();
        }
    }

    /**
     * Delete all gallery images of the property
     *
     * @param Property $property
     * @return void
     */
    private function deleteAdditionalImage(Property $property): void
    {
        if ($property->images()->exists()) {
            foreach ($property->images as $image) {
                $this->deleteFile($image->name, 'properties');
            }
            $property->images()->delete();
        }
    }
}
