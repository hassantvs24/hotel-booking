<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Relations\MorphOne;

class Room extends Model
{
    protected $with = ['primaryImage'];
    protected $appends = ['primary_image_url'];

    /*----------------------------------------
     * Relationships
     ----------------------------------------*/
    public function primaryImage(): MorphOne
    {
        return $this->morphOne(Media::class, 'media')->where('media_role', 'room_image');
    }

    public function images(): MorphMany
    {
        return $this->morphMany(Media::class, 'media')->where('media_role', 'room_gallery_image');
    }

    public function property(): BelongsTo
    {
        return $this->belongsTo(Property::class);
    }

    // Relationship: active room prices (is_activated = 1)
    public function activePrices(): HasMany
    {
        return $this->hasMany(RoomPrice::class)
            ->where('is_activated', 1);
    }

// Relationship: all room prices
    public function prices(): HasMany
    {
        return $this->hasMany(RoomPrice::class);
    }

    public function roomType(): BelongsTo
    {
        return $this->belongsTo(RoomType::class);
    }

    public function bedType(): BelongsTo
    {
        return $this->belongsTo(BedType::class);
    }

    public function extraFacilities(): BelongsToMany
    {
        return $this->belongsToMany(RoomExtraFacility::class);
    }

    public function facilities(): BelongsToMany
    {
        return $this->belongsToMany(FacilitySub::class, 'room_facility_setups')->withTimestamps();
    }

    public function bookings(): HasMany
    {
        return $this->hasMany(Booking::class);
    }
    public function roomRequests(): HasMany
    {
        return $this->hasMany(RoomRequest::class);
    }


    /*----------------------------------------
     * Accessors
     ----------------------------------------*/
    public function getPrimaryImageUrlAttribute(): string
    {
        $imageUrl = asset('assets/default/default_room.jpg');

        if ($this->primaryImage()->exists()) {
            $imageUrl = $this->relations['primaryImage']->url;
        }

        return $imageUrl;
    }

    /*----------------------------------------
     * Attributes
     ----------------------------------------*/
    public function basePrice(): Attribute
    {
        return new Attribute(
            fn($value) => $value / 100,
            fn($value) => $value * 100
        );
    }
}
