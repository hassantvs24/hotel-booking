<?php return array (
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => '12',
      'verify' => true,
    ),
    'argon' => 
    array (
      'memory' => 65536,
      'threads' => 1,
      'time' => 4,
      'verify' => true,
    ),
    'rehash_on_login' => true,
  ),
  'concurrency' => 
  array (
    'default' => 'process',
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => '/Volumes/Development/projects/oystay/hotel-booking/resources/views',
    ),
    'compiled' => '/Volumes/Development/projects/oystay/hotel-booking/storage/framework/views',
  ),
  'app' => 
  array (
    'name' => 'Laravel',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost',
    'frontend_url' => 'http://hotel-booking.test:5173/',
    'asset_url' => NULL,
    'timezone' => 'UTC',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'cipher' => 'AES-256-CBC',
    'key' => 'base64:hwWKtvbFOxM1jKQEiT6sx57t6LXux1H1mAfiMeE64lQ=',
    'previous_keys' => 
    array (
    ),
    'maintenance' => 
    array (
      'driver' => 'file',
      'store' => 'database',
    ),
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Concurrency\\ConcurrencyServiceProvider',
      6 => 'Illuminate\\Cookie\\CookieServiceProvider',
      7 => 'Illuminate\\Database\\DatabaseServiceProvider',
      8 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      9 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      10 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      11 => 'Illuminate\\Hashing\\HashServiceProvider',
      12 => 'Illuminate\\Mail\\MailServiceProvider',
      13 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      14 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      15 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      16 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      17 => 'Illuminate\\Queue\\QueueServiceProvider',
      18 => 'Illuminate\\Redis\\RedisServiceProvider',
      19 => 'Illuminate\\Session\\SessionServiceProvider',
      20 => 'Illuminate\\Translation\\TranslationServiceProvider',
      21 => 'Illuminate\\Validation\\ValidationServiceProvider',
      22 => 'Illuminate\\View\\ViewServiceProvider',
      23 => 'App\\Providers\\AppServiceProvider',
      24 => 'App\\Providers\\BroadcastServiceProvider',
      25 => 'App\\Providers\\TelescopeServiceProvider',
      26 => 'Spatie\\Permission\\PermissionServiceProvider',
      27 => 'Laravel\\Socialite\\SocialiteServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Concurrency' => 'Illuminate\\Support\\Facades\\Concurrency',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Context' => 'Illuminate\\Support\\Facades\\Context',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'Date' => 'Illuminate\\Support\\Facades\\Date',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Js' => 'Illuminate\\Support\\Js',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Number' => 'Illuminate\\Support\\Number',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Process' => 'Illuminate\\Support\\Facades\\Process',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'RateLimiter' => 'Illuminate\\Support\\Facades\\RateLimiter',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schedule' => 'Illuminate\\Support\\Facades\\Schedule',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Uri' => 'Illuminate\\Support\\Uri',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Vite' => 'Illuminate\\Support\\Facades\\Vite',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'sanctum' => 
      array (
        'driver' => 'sanctum',
        'provider' => NULL,
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_reset_tokens',
        'expire' => 60,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'broadcasting' => 
  array (
    'default' => 'reverb',
    'connections' => 
    array (
      'reverb' => 
      array (
        'driver' => 'reverb',
        'key' => 'b1b4sibelyrmvpcyearl',
        'secret' => 'te9xt7arhdyfnelvuvvf',
        'app_id' => '885000',
        'options' => 
        array (
          'host' => 'localhost',
          'port' => '8080',
          'scheme' => 'http',
          'useTLS' => false,
        ),
        'client_options' => 
        array (
        ),
      ),
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => NULL,
        'secret' => NULL,
        'app_id' => NULL,
        'options' => 
        array (
          'cluster' => NULL,
          'host' => 'api-mt1.pusher.com',
          'port' => 443,
          'scheme' => 'https',
          'encrypted' => true,
          'useTLS' => true,
        ),
        'client_options' => 
        array (
        ),
      ),
      'ably' => 
      array (
        'driver' => 'ably',
        'key' => NULL,
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'database',
    'stores' => 
    array (
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
        'lock_connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => '/Volumes/Development/projects/oystay/hotel-booking/storage/framework/cache/data',
        'lock_path' => '/Volumes/Development/projects/oystay/hotel-booking/storage/framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
        'lock_connection' => 'default',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
      'octane' => 
      array (
        'driver' => 'octane',
      ),
    ),
    'prefix' => '',
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
      1 => 'portal/*',
      2 => 'sanctum/csrf-cookie',
      3 => 'broadcasting/auth',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => 'http://hotel-booking.test:5173/',
      1 => 'http://hotel-booking.test:5174/',
      2 => 'http://hotel-booking.test:5173',
      3 => 'http://hotel-booking.test:5174',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => true,
  ),
  'countries' => 
  array (
    'lists' => 
    array (
      0 => 
      array (
        'name' => 'Afghanistan',
        'country_code' => 'AF',
        'short_name' => 'AFG',
        'currency' => 'Afghan afghani',
        'currency_code' => 'AFN',
        'language' => 'Pashto, Dari',
        'flag' => '🇦🇫',
      ),
      1 => 
      array (
        'name' => 'Albania',
        'country_code' => 'AL',
        'short_name' => 'ALB',
        'currency' => 'Albanian lek',
        'currency_code' => 'ALL',
        'language' => 'Albanian',
        'flag' => '🇦🇱',
      ),
      2 => 
      array (
        'name' => 'Algeria',
        'country_code' => 'DZ',
        'short_name' => 'DZA',
        'currency' => 'Algerian dinar',
        'currency_code' => 'DZD',
        'language' => 'Arabic',
        'flag' => '🇩🇿',
      ),
      3 => 
      array (
        'name' => 'Andorra',
        'country_code' => 'AD',
        'short_name' => 'AND',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Catalan',
        'flag' => '🇦🇩',
      ),
      4 => 
      array (
        'name' => 'Angola',
        'country_code' => 'AO',
        'short_name' => 'AGO',
        'currency' => 'Angolan kwanza',
        'currency_code' => 'AOA',
        'language' => 'Portuguese',
        'flag' => '🇦🇴',
      ),
      5 => 
      array (
        'name' => 'Antigua and Barbuda',
        'country_code' => 'AG',
        'short_name' => 'ATG',
        'currency' => 'East Caribbean dollar',
        'currency_code' => 'XCD',
        'language' => 'English',
        'flag' => '🇦🇬',
      ),
      6 => 
      array (
        'name' => 'Argentina',
        'country_code' => 'AR',
        'short_name' => 'ARG',
        'currency' => 'Argentine peso',
        'currency_code' => 'ARS',
        'language' => 'Spanish',
        'flag' => '🇦🇷',
      ),
      7 => 
      array (
        'name' => 'Armenia',
        'country_code' => 'AM',
        'short_name' => 'ARM',
        'currency' => 'Armenian dram',
        'currency_code' => 'AMD',
        'language' => 'Armenian',
        'flag' => '🇦🇲',
      ),
      8 => 
      array (
        'name' => 'Australia',
        'country_code' => 'AU',
        'short_name' => 'AUS',
        'currency' => 'Australian dollar',
        'currency_code' => 'AUD',
        'language' => 'English',
        'flag' => '🇦🇺',
      ),
      9 => 
      array (
        'name' => 'Austria',
        'country_code' => 'AT',
        'short_name' => 'AUT',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'German',
        'flag' => '🇦🇹',
      ),
      10 => 
      array (
        'name' => 'Azerbaijan',
        'country_code' => 'AZ',
        'short_name' => 'AZE',
        'currency' => 'Azerbaijani manat',
        'currency_code' => 'AZN',
        'language' => 'Azerbaijani',
        'flag' => '🇦🇿',
      ),
      11 => 
      array (
        'name' => 'Bahamas',
        'country_code' => 'BS',
        'short_name' => 'BHS',
        'currency' => 'Bahamian dollar',
        'currency_code' => 'BSD',
        'language' => 'English',
        'flag' => '🇧🇸',
      ),
      12 => 
      array (
        'name' => 'Bahrain',
        'country_code' => 'BH',
        'short_name' => 'BHR',
        'currency' => 'Bahraini dinar',
        'currency_code' => 'BHD',
        'language' => 'Arabic',
        'flag' => '🇧🇭',
      ),
      13 => 
      array (
        'name' => 'Bangladesh',
        'country_code' => 'BD',
        'short_name' => 'BGD',
        'currency' => 'Bangladeshi taka',
        'currency_code' => 'BDT',
        'language' => 'Bengali',
        'flag' => '🇧🇩',
      ),
      14 => 
      array (
        'name' => 'Barbados',
        'country_code' => 'BB',
        'short_name' => 'BRB',
        'currency' => 'Barbadian dollar',
        'currency_code' => 'BBD',
        'language' => 'English',
        'flag' => '🇧🇧',
      ),
      15 => 
      array (
        'name' => 'Belarus',
        'country_code' => 'BY',
        'short_name' => 'BLR',
        'currency' => 'Belarusian ruble',
        'currency_code' => 'BYN',
        'language' => 'Belarusian, Russian',
        'flag' => '🇧🇾',
      ),
      16 => 
      array (
        'name' => 'Belgium',
        'country_code' => 'BE',
        'short_name' => 'BEL',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Dutch, French, German',
        'flag' => '🇧🇪',
      ),
      17 => 
      array (
        'name' => 'Belize',
        'country_code' => 'BZ',
        'short_name' => 'BLZ',
        'currency' => 'Belize dollar',
        'currency_code' => 'BZD',
        'language' => 'English',
        'flag' => '🇧🇿',
      ),
      18 => 
      array (
        'name' => 'Benin',
        'country_code' => 'BJ',
        'short_name' => 'BEN',
        'currency' => 'West African CFA franc',
        'currency_code' => 'XOF',
        'language' => 'French',
        'flag' => '🇧🇯',
      ),
      19 => 
      array (
        'name' => 'Bhutan',
        'country_code' => 'BT',
        'short_name' => 'BTN',
        'currency' => 'Bhutanese ngultrum',
        'currency_code' => 'BTN',
        'language' => 'Dzongkha',
        'flag' => '🇧🇹',
      ),
      20 => 
      array (
        'name' => 'Bolivia',
        'country_code' => 'BO',
        'short_name' => 'BOL',
        'currency' => 'Bolivian boliviano',
        'currency_code' => 'BOB',
        'language' => 'Spanish, Quechua, Aymara',
        'flag' => '🇧🇴',
      ),
      21 => 
      array (
        'name' => 'Bosnia and Herzegovina',
        'country_code' => 'BA',
        'short_name' => 'BIH',
        'currency' => 'Bosnia and Herzegovina convertible mark',
        'currency_code' => 'BAM',
        'language' => 'Bosnian, Croatian, Serbian',
        'flag' => '🇧🇦',
      ),
      22 => 
      array (
        'name' => 'Botswana',
        'country_code' => 'BW',
        'short_name' => 'BWA',
        'currency' => 'Botswana pula',
        'currency_code' => 'BWP',
        'language' => 'English, Tswana',
        'flag' => '🇧🇼',
      ),
      23 => 
      array (
        'name' => 'Brazil',
        'country_code' => 'BR',
        'short_name' => 'BRA',
        'currency' => 'Brazilian real',
        'currency_code' => 'BRL',
        'language' => 'Portuguese',
        'flag' => '🇧🇷',
      ),
      24 => 
      array (
        'name' => 'Brunei',
        'country_code' => 'BN',
        'short_name' => 'BRN',
        'currency' => 'Brunei dollar',
        'currency_code' => 'BND',
        'language' => 'Malay',
        'flag' => '🇧🇳',
      ),
      25 => 
      array (
        'name' => 'Bulgaria',
        'country_code' => 'BG',
        'short_name' => 'BGR',
        'currency' => 'Bulgarian lev',
        'currency_code' => 'BGN',
        'language' => 'Bulgarian',
        'flag' => '🇧🇬',
      ),
      26 => 
      array (
        'name' => 'Burkina Faso',
        'country_code' => 'BF',
        'short_name' => 'BFA',
        'currency' => 'West African CFA franc',
        'currency_code' => 'XOF',
        'language' => 'French',
        'flag' => '🇧🇫',
      ),
      27 => 
      array (
        'name' => 'Burundi',
        'country_code' => 'BI',
        'short_name' => 'BDI',
        'currency' => 'Burundian franc',
        'currency_code' => 'BIF',
        'language' => 'Kirundi, French',
        'flag' => '🇧🇮',
      ),
      28 => 
      array (
        'name' => 'Cabo Verde',
        'country_code' => 'CV',
        'short_name' => 'CPV',
        'currency' => 'Cape Verdean escudo',
        'currency_code' => 'CVE',
        'language' => 'Portuguese',
        'flag' => '🇨🇻',
      ),
      29 => 
      array (
        'name' => 'Cambodia',
        'country_code' => 'KH',
        'short_name' => 'KHM',
        'currency' => 'Cambodian riel',
        'currency_code' => 'KHR',
        'language' => 'Khmer',
        'flag' => '🇰🇭',
      ),
      30 => 
      array (
        'name' => 'Cameroon',
        'country_code' => 'CM',
        'short_name' => 'CMR',
        'currency' => 'Central African CFA franc',
        'currency_code' => 'XAF',
        'language' => 'French, English',
        'flag' => '🇨🇲',
      ),
      31 => 
      array (
        'name' => 'Canada',
        'country_code' => 'CA',
        'short_name' => 'CAN',
        'currency' => 'Canadian dollar',
        'currency_code' => 'CAD',
        'language' => 'English, French',
        'flag' => '🇨🇦',
      ),
      32 => 
      array (
        'name' => 'Central African Republic',
        'country_code' => 'CF',
        'short_name' => 'CAF',
        'currency' => 'Central African CFA franc',
        'currency_code' => 'XAF',
        'language' => 'French, Sango',
        'flag' => '🇨🇫',
      ),
      33 => 
      array (
        'name' => 'Chad',
        'country_code' => 'TD',
        'short_name' => 'TCD',
        'currency' => 'Central African CFA franc',
        'currency_code' => 'XAF',
        'language' => 'French, Arabic',
        'flag' => '🇹🇩',
      ),
      34 => 
      array (
        'name' => 'Chile',
        'country_code' => 'CL',
        'short_name' => 'CHL',
        'currency' => 'Chilean peso',
        'currency_code' => 'CLP',
        'language' => 'Spanish',
        'flag' => '🇨🇱',
      ),
      35 => 
      array (
        'name' => 'China',
        'country_code' => 'CN',
        'short_name' => 'CHN',
        'currency' => 'Renminbi',
        'currency_code' => 'CNY',
        'language' => 'Mandarin',
        'flag' => '🇨🇳',
      ),
      36 => 
      array (
        'name' => 'Colombia',
        'country_code' => 'CO',
        'short_name' => 'COL',
        'currency' => 'Colombian peso',
        'currency_code' => 'COP',
        'language' => 'Spanish',
        'flag' => '🇨🇴',
      ),
      37 => 
      array (
        'name' => 'Comoros',
        'country_code' => 'KM',
        'short_name' => 'COM',
        'currency' => 'Comorian franc',
        'currency_code' => 'KMF',
        'language' => 'Comorian, Arabic, French',
        'flag' => '🇰🇲',
      ),
      38 => 
      array (
        'name' => 'Congo, Democratic Republic of the',
        'country_code' => 'CD',
        'short_name' => 'COD',
        'currency' => 'Congolese franc',
        'currency_code' => 'CDF',
        'language' => 'French',
        'flag' => '🇨🇩',
      ),
      39 => 
      array (
        'name' => 'Congo, Republic of the',
        'country_code' => 'CG',
        'short_name' => 'COG',
        'currency' => 'Central African CFA franc',
        'currency_code' => 'XAF',
        'language' => 'French, Lingala',
        'flag' => '🇨🇬',
      ),
      40 => 
      array (
        'name' => 'Costa Rica',
        'country_code' => 'CR',
        'short_name' => 'CRI',
        'currency' => 'Costa Rican colón',
        'currency_code' => 'CRC',
        'language' => 'Spanish',
        'flag' => '🇨🇷',
      ),
      41 => 
      array (
        'name' => 'Croatia',
        'country_code' => 'HR',
        'short_name' => 'HRV',
        'currency' => 'Croatian kuna',
        'currency_code' => 'HRK',
        'language' => 'Croatian',
        'flag' => '🇭🇷',
      ),
      42 => 
      array (
        'name' => 'Cuba',
        'country_code' => 'CU',
        'short_name' => 'CUB',
        'currency' => 'Cuban peso',
        'currency_code' => 'CUP',
        'language' => 'Spanish',
        'flag' => '🇨🇺',
      ),
      43 => 
      array (
        'name' => 'Cyprus',
        'country_code' => 'CY',
        'short_name' => 'CYP',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Greek, Turkish',
        'flag' => '🇨🇾',
      ),
      44 => 
      array (
        'name' => 'Czech Republic',
        'country_code' => 'CZ',
        'short_name' => 'CZE',
        'currency' => 'Czech koruna',
        'currency_code' => 'CZK',
        'language' => 'Czech',
        'flag' => '🇨🇿',
      ),
      45 => 
      array (
        'name' => 'Denmark',
        'country_code' => 'DK',
        'short_name' => 'DNK',
        'currency' => 'Danish krone',
        'currency_code' => 'DKK',
        'language' => 'Danish',
        'flag' => '🇩🇰',
      ),
      46 => 
      array (
        'name' => 'Djibouti',
        'country_code' => 'DJ',
        'short_name' => 'DJI',
        'currency' => 'Djiboutian franc',
        'currency_code' => 'DJF',
        'language' => 'French, Arabic',
        'flag' => '🇩🇯',
      ),
      47 => 
      array (
        'name' => 'Dominica',
        'country_code' => 'DM',
        'short_name' => 'DMA',
        'currency' => 'East Caribbean dollar',
        'currency_code' => 'XCD',
        'language' => 'English',
        'flag' => '🇩🇲',
      ),
      48 => 
      array (
        'name' => 'Dominican Republic',
        'country_code' => 'DO',
        'short_name' => 'DOM',
        'currency' => 'Dominican peso',
        'currency_code' => 'DOP',
        'language' => 'Spanish',
        'flag' => '🇩🇴',
      ),
      49 => 
      array (
        'name' => 'Ecuador',
        'country_code' => 'EC',
        'short_name' => 'ECU',
        'currency' => 'United States dollar',
        'currency_code' => 'USD',
        'language' => 'Spanish',
        'flag' => '🇪🇨',
      ),
      50 => 
      array (
        'name' => 'Egypt',
        'country_code' => 'EG',
        'short_name' => 'EGY',
        'currency' => 'Egyptian pound',
        'currency_code' => 'EGP',
        'language' => 'Arabic',
        'flag' => '🇪🇬',
      ),
      51 => 
      array (
        'name' => 'El Salvador',
        'country_code' => 'SV',
        'short_name' => 'SLV',
        'currency' => 'United States dollar',
        'currency_code' => 'USD',
        'language' => 'Spanish',
        'flag' => '🇸🇻',
      ),
      52 => 
      array (
        'name' => 'Equatorial Guinea',
        'country_code' => 'GQ',
        'short_name' => 'GNQ',
        'currency' => 'Central African CFA franc',
        'currency_code' => 'XAF',
        'language' => 'Spanish, French, Portuguese',
        'flag' => '🇬🇶',
      ),
      53 => 
      array (
        'name' => 'Eritrea',
        'country_code' => 'ER',
        'short_name' => 'ERI',
        'currency' => 'Eritrean nakfa',
        'currency_code' => 'ERN',
        'language' => 'Tigrinya, Arabic, English',
        'flag' => '🇪🇷',
      ),
      54 => 
      array (
        'name' => 'Estonia',
        'country_code' => 'EE',
        'short_name' => 'EST',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Estonian',
        'flag' => '🇪🇪',
      ),
      55 => 
      array (
        'name' => 'Eswatini',
        'country_code' => 'SZ',
        'short_name' => 'SWZ',
        'currency' => 'Swazi lilangeni',
        'currency_code' => 'SZL',
        'language' => 'Swazi, English',
        'flag' => '🇸🇿',
      ),
      56 => 
      array (
        'name' => 'Ethiopia',
        'country_code' => 'ET',
        'short_name' => 'ETH',
        'currency' => 'Ethiopian birr',
        'currency_code' => 'ETB',
        'language' => 'Amharic',
        'flag' => '🇪🇹',
      ),
      57 => 
      array (
        'name' => 'Fiji',
        'country_code' => 'FJ',
        'short_name' => 'FJI',
        'currency' => 'Fijian dollar',
        'currency_code' => 'FJD',
        'language' => 'English, Fijian, Hindi',
        'flag' => '🇫🇯',
      ),
      58 => 
      array (
        'name' => 'Finland',
        'country_code' => 'FI',
        'short_name' => 'FIN',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Finnish, Swedish',
        'flag' => '🇫🇮',
      ),
      59 => 
      array (
        'name' => 'France',
        'country_code' => 'FR',
        'short_name' => 'FRA',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'French',
        'flag' => '🇫🇷',
      ),
      60 => 
      array (
        'name' => 'Gabon',
        'country_code' => 'GA',
        'short_name' => 'GAB',
        'currency' => 'Central African CFA franc',
        'currency_code' => 'XAF',
        'language' => 'French',
        'flag' => '🇬🇦',
      ),
      61 => 
      array (
        'name' => 'Gambia',
        'country_code' => 'GM',
        'short_name' => 'GMB',
        'currency' => 'Gambian dalasi',
        'currency_code' => 'GMD',
        'language' => 'English',
        'flag' => '🇬🇲',
      ),
      62 => 
      array (
        'name' => 'Georgia',
        'country_code' => 'GE',
        'short_name' => 'GEO',
        'currency' => 'Georgian lari',
        'currency_code' => 'GEL',
        'language' => 'Georgian',
        'flag' => '🇬🇪',
      ),
      63 => 
      array (
        'name' => 'Germany',
        'country_code' => 'DE',
        'short_name' => 'DEU',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'German',
        'flag' => '🇩🇪',
      ),
      64 => 
      array (
        'name' => 'Ghana',
        'country_code' => 'GH',
        'short_name' => 'GHA',
        'currency' => 'Ghanaian cedi',
        'currency_code' => 'GHS',
        'language' => 'English',
        'flag' => '🇬🇭',
      ),
      65 => 
      array (
        'name' => 'Greece',
        'country_code' => 'GR',
        'short_name' => 'GRC',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Greek',
        'flag' => '🇬🇷',
      ),
      66 => 
      array (
        'name' => 'Grenada',
        'country_code' => 'GD',
        'short_name' => 'GRD',
        'currency' => 'East Caribbean dollar',
        'currency_code' => 'XCD',
        'language' => 'English',
        'flag' => '🇬🇩',
      ),
      67 => 
      array (
        'name' => 'Guatemala',
        'country_code' => 'GT',
        'short_name' => 'GTM',
        'currency' => 'Guatemalan quetzal',
        'currency_code' => 'GTQ',
        'language' => 'Spanish',
        'flag' => '🇬🇹',
      ),
      68 => 
      array (
        'name' => 'Guinea',
        'country_code' => 'GN',
        'short_name' => 'GIN',
        'currency' => 'Guinean franc',
        'currency_code' => 'GNF',
        'language' => 'French',
        'flag' => '🇬🇳',
      ),
      69 => 
      array (
        'name' => 'Guinea-Bissau',
        'country_code' => 'GW',
        'short_name' => 'GNB',
        'currency' => 'West African CFA franc',
        'currency_code' => 'XOF',
        'language' => 'Portuguese',
        'flag' => '🇬🇼',
      ),
      70 => 
      array (
        'name' => 'Guyana',
        'country_code' => 'GY',
        'short_name' => 'GUY',
        'currency' => 'Guyanese dollar',
        'currency_code' => 'GYD',
        'language' => 'English',
        'flag' => '🇬🇾',
      ),
      71 => 
      array (
        'name' => 'Haiti',
        'country_code' => 'HT',
        'short_name' => 'HTI',
        'currency' => 'Haitian gourde',
        'currency_code' => 'HTG',
        'language' => 'French, Haitian Creole',
        'flag' => '🇭🇹',
      ),
      72 => 
      array (
        'name' => 'Honduras',
        'country_code' => 'HN',
        'short_name' => 'HND',
        'currency' => 'Honduran lempira',
        'currency_code' => 'HNL',
        'language' => 'Spanish',
        'flag' => '🇭🇳',
      ),
      73 => 
      array (
        'name' => 'Hungary',
        'country_code' => 'HU',
        'short_name' => 'HUN',
        'currency' => 'Hungarian forint',
        'currency_code' => 'HUF',
        'language' => 'Hungarian',
        'flag' => '🇭🇺',
      ),
      74 => 
      array (
        'name' => 'Iceland',
        'country_code' => 'IS',
        'short_name' => 'ISL',
        'currency' => 'Icelandic króna',
        'currency_code' => 'ISK',
        'language' => 'Icelandic',
        'flag' => '🇮🇸',
      ),
      75 => 
      array (
        'name' => 'India',
        'country_code' => 'IN',
        'short_name' => 'IND',
        'currency' => 'Indian rupee',
        'currency_code' => 'INR',
        'language' => 'Hindi, English',
        'flag' => '🇮🇳',
      ),
      76 => 
      array (
        'name' => 'Indonesia',
        'country_code' => 'ID',
        'short_name' => 'IDN',
        'currency' => 'Indonesian rupiah',
        'currency_code' => 'IDR',
        'language' => 'Indonesian',
        'flag' => '🇮🇩',
      ),
      77 => 
      array (
        'name' => 'Iran',
        'country_code' => 'IR',
        'short_name' => 'IRN',
        'currency' => 'Iranian rial',
        'currency_code' => 'IRR',
        'language' => 'Persian',
        'flag' => '🇮🇷',
      ),
      78 => 
      array (
        'name' => 'Iraq',
        'country_code' => 'IQ',
        'short_name' => 'IRQ',
        'currency' => 'Iraqi dinar',
        'currency_code' => 'IQD',
        'language' => 'Arabic, Kurdish',
        'flag' => '🇮🇶',
      ),
      79 => 
      array (
        'name' => 'Ireland',
        'country_code' => 'IE',
        'short_name' => 'IRL',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Irish, English',
        'flag' => '🇮🇪',
      ),
      80 => 
      array (
        'name' => 'Israel',
        'country_code' => 'IL',
        'short_name' => 'ISR',
        'currency' => 'Israeli new shekel',
        'currency_code' => 'ILS',
        'language' => 'Hebrew, Arabic',
        'flag' => '🇮🇱',
      ),
      81 => 
      array (
        'name' => 'Italy',
        'country_code' => 'IT',
        'short_name' => 'ITA',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Italian',
        'flag' => '🇮🇹',
      ),
      82 => 
      array (
        'name' => 'Jamaica',
        'country_code' => 'JM',
        'short_name' => 'JAM',
        'currency' => 'Jamaican dollar',
        'currency_code' => 'JMD',
        'language' => 'English',
        'flag' => '🇯🇲',
      ),
      83 => 
      array (
        'name' => 'Japan',
        'country_code' => 'JP',
        'short_name' => 'JPN',
        'currency' => 'Japanese yen',
        'currency_code' => 'JPY',
        'language' => 'Japanese',
        'flag' => '🇯🇵',
      ),
      84 => 
      array (
        'name' => 'Jordan',
        'country_code' => 'JO',
        'short_name' => 'JOR',
        'currency' => 'Jordanian dinar',
        'currency_code' => 'JOD',
        'language' => 'Arabic',
        'flag' => '🇯🇴',
      ),
      85 => 
      array (
        'name' => 'Kazakhstan',
        'country_code' => 'KZ',
        'short_name' => 'KAZ',
        'currency' => 'Kazakhstani tenge',
        'currency_code' => 'KZT',
        'language' => 'Kazakh, Russian',
        'flag' => '🇰🇿',
      ),
      86 => 
      array (
        'name' => 'Kenya',
        'country_code' => 'KE',
        'short_name' => 'KEN',
        'currency' => 'Kenyan shilling',
        'currency_code' => 'KES',
        'language' => 'Swahili, English',
        'flag' => '🇰🇪',
      ),
      87 => 
      array (
        'name' => 'Kiribati',
        'country_code' => 'KI',
        'short_name' => 'KIR',
        'currency' => 'Australian dollar',
        'currency_code' => 'AUD',
        'language' => 'English, Gilbertese',
        'flag' => '🇰🇮',
      ),
      88 => 
      array (
        'name' => 'Kuwait',
        'country_code' => 'KW',
        'short_name' => 'KWT',
        'currency' => 'Kuwaiti dinar',
        'currency_code' => 'KWD',
        'language' => 'Arabic',
        'flag' => '🇰🇼',
      ),
      89 => 
      array (
        'name' => 'Kyrgyzstan',
        'country_code' => 'KG',
        'short_name' => 'KGZ',
        'currency' => 'Kyrgyzstani som',
        'currency_code' => 'KGS',
        'language' => 'Kyrgyz, Russian',
        'flag' => '🇰🇬',
      ),
      90 => 
      array (
        'name' => 'Laos',
        'country_code' => 'LA',
        'short_name' => 'LAO',
        'currency' => 'Lao kip',
        'currency_code' => 'LAK',
        'language' => 'Lao',
        'flag' => '🇱🇦',
      ),
      91 => 
      array (
        'name' => 'Latvia',
        'country_code' => 'LV',
        'short_name' => 'LVA',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Latvian',
        'flag' => '🇱🇻',
      ),
      92 => 
      array (
        'name' => 'Lebanon',
        'country_code' => 'LB',
        'short_name' => 'LBN',
        'currency' => 'Lebanese pound',
        'currency_code' => 'LBP',
        'language' => 'Arabic',
        'flag' => '🇱🇧',
      ),
      93 => 
      array (
        'name' => 'Lesotho',
        'country_code' => 'LS',
        'short_name' => 'LSO',
        'currency' => 'Lesotho loti',
        'currency_code' => 'LSL',
        'language' => 'Sesotho, English',
        'flag' => '🇱🇸',
      ),
      94 => 
      array (
        'name' => 'Liberia',
        'country_code' => 'LR',
        'short_name' => 'LBR',
        'currency' => 'Liberian dollar',
        'currency_code' => 'LRD',
        'language' => 'English',
        'flag' => '🇱🇷',
      ),
      95 => 
      array (
        'name' => 'Libya',
        'country_code' => 'LY',
        'short_name' => 'LBY',
        'currency' => 'Libyan dinar',
        'currency_code' => 'LYD',
        'language' => 'Arabic',
        'flag' => '🇱🇾',
      ),
      96 => 
      array (
        'name' => 'Liechtenstein',
        'country_code' => 'LI',
        'short_name' => 'LIE',
        'currency' => 'Swiss franc',
        'currency_code' => 'CHF',
        'language' => 'German',
        'flag' => '🇱🇮',
      ),
      97 => 
      array (
        'name' => 'Lithuania',
        'country_code' => 'LT',
        'short_name' => 'LTU',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Lithuanian',
        'flag' => '🇱🇹',
      ),
      98 => 
      array (
        'name' => 'Luxembourg',
        'country_code' => 'LU',
        'short_name' => 'LUX',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Luxembourgish, French, German',
        'flag' => '🇱🇺',
      ),
      99 => 
      array (
        'name' => 'Madagascar',
        'country_code' => 'MG',
        'short_name' => 'MDG',
        'currency' => 'Malagasy ariary',
        'currency_code' => 'MGA',
        'language' => 'Malagasy, French',
        'flag' => '🇲🇬',
      ),
      100 => 
      array (
        'name' => 'Malawi',
        'country_code' => 'MW',
        'short_name' => 'MWI',
        'currency' => 'Malawian kwacha',
        'currency_code' => 'MWK',
        'language' => 'English, Chichewa',
        'flag' => '🇲🇼',
      ),
      101 => 
      array (
        'name' => 'Malaysia',
        'country_code' => 'MY',
        'short_name' => 'MYS',
        'currency' => 'Malaysian ringgit',
        'currency_code' => 'MYR',
        'language' => 'Malay',
        'flag' => '🇲🇾',
      ),
      102 => 
      array (
        'name' => 'Maldives',
        'country_code' => 'MV',
        'short_name' => 'MDV',
        'currency' => 'Maldivian rufiyaa',
        'currency_code' => 'MVR',
        'language' => 'Dhivehi',
        'flag' => '🇲🇻',
      ),
      103 => 
      array (
        'name' => 'Mali',
        'country_code' => 'ML',
        'short_name' => 'MLI',
        'currency' => 'West African CFA franc',
        'currency_code' => 'XOF',
        'language' => 'French',
        'flag' => '🇲🇱',
      ),
      104 => 
      array (
        'name' => 'Malta',
        'country_code' => 'MT',
        'short_name' => 'MLT',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Maltese, English',
        'flag' => '🇲🇹',
      ),
      105 => 
      array (
        'name' => 'Marshall Islands',
        'country_code' => 'MH',
        'short_name' => 'MHL',
        'currency' => 'United States dollar',
        'currency_code' => 'USD',
        'language' => 'Marshallese, English',
        'flag' => '🇲🇭',
      ),
      106 => 
      array (
        'name' => 'Mauritania',
        'country_code' => 'MR',
        'short_name' => 'MRT',
        'currency' => 'Mauritanian ouguiya',
        'currency_code' => 'MRU',
        'language' => 'Arabic',
        'flag' => '🇲🇷',
      ),
      107 => 
      array (
        'name' => 'Mauritius',
        'country_code' => 'MU',
        'short_name' => 'MUS',
        'currency' => 'Mauritian rupee',
        'currency_code' => 'MUR',
        'language' => 'English, French',
        'flag' => '🇲🇺',
      ),
      108 => 
      array (
        'name' => 'Mexico',
        'country_code' => 'MX',
        'short_name' => 'MEX',
        'currency' => 'Mexican peso',
        'currency_code' => 'MXN',
        'language' => 'Spanish',
        'flag' => '🇲🇽',
      ),
      109 => 
      array (
        'name' => 'Micronesia',
        'country_code' => 'FM',
        'short_name' => 'FSM',
        'currency' => 'United States dollar',
        'currency_code' => 'USD',
        'language' => 'English',
        'flag' => '🇫🇲',
      ),
      110 => 
      array (
        'name' => 'Moldova',
        'country_code' => 'MD',
        'short_name' => 'MDA',
        'currency' => 'Moldovan leu',
        'currency_code' => 'MDL',
        'language' => 'Romanian',
        'flag' => '🇲🇩',
      ),
      111 => 
      array (
        'name' => 'Monaco',
        'country_code' => 'MC',
        'short_name' => 'MCO',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'French',
        'flag' => '🇲🇨',
      ),
      112 => 
      array (
        'name' => 'Mongolia',
        'country_code' => 'MN',
        'short_name' => 'MNG',
        'currency' => 'Mongolian tögrög',
        'currency_code' => 'MNT',
        'language' => 'Mongolian',
        'flag' => '🇲🇳',
      ),
      113 => 
      array (
        'name' => 'Montenegro',
        'country_code' => 'ME',
        'short_name' => 'MNE',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Montenegrin',
        'flag' => '🇲🇪',
      ),
      114 => 
      array (
        'name' => 'Morocco',
        'country_code' => 'MA',
        'short_name' => 'MAR',
        'currency' => 'Moroccan dirham',
        'currency_code' => 'MAD',
        'language' => 'Arabic',
        'flag' => '🇲🇦',
      ),
      115 => 
      array (
        'name' => 'Mozambique',
        'country_code' => 'MZ',
        'short_name' => 'MOZ',
        'currency' => 'Mozambican metical',
        'currency_code' => 'MZN',
        'language' => 'Portuguese',
        'flag' => '🇲🇿',
      ),
      116 => 
      array (
        'name' => 'Myanmar (Burma)',
        'country_code' => 'MM',
        'short_name' => 'MMR',
        'currency' => 'Burmese kyat',
        'currency_code' => 'MMK',
        'language' => 'Burmese',
        'flag' => '🇲🇲',
      ),
      117 => 
      array (
        'name' => 'Namibia',
        'country_code' => 'NA',
        'short_name' => 'NAM',
        'currency' => 'Namibian dollar',
        'currency_code' => 'NAD',
        'language' => 'English',
        'flag' => '🇳🇦',
      ),
      118 => 
      array (
        'name' => 'Nauru',
        'country_code' => 'NR',
        'short_name' => 'NRU',
        'currency' => 'Australian dollar',
        'currency_code' => 'AUD',
        'language' => 'Nauruan, English',
        'flag' => '🇳🇷',
      ),
      119 => 
      array (
        'name' => 'Nepal',
        'country_code' => 'NP',
        'short_name' => 'NPL',
        'currency' => 'Nepalese rupee',
        'currency_code' => 'NPR',
        'language' => 'Nepali',
        'flag' => '🇳🇵',
      ),
      120 => 
      array (
        'name' => 'Netherlands',
        'country_code' => 'NL',
        'short_name' => 'NLD',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Dutch',
        'flag' => '🇳🇱',
      ),
      121 => 
      array (
        'name' => 'New Zealand',
        'country_code' => 'NZ',
        'short_name' => 'NZL',
        'currency' => 'New Zealand dollar',
        'currency_code' => 'NZD',
        'language' => 'English, Maori',
        'flag' => '🇳🇿',
      ),
      122 => 
      array (
        'name' => 'Nicaragua',
        'country_code' => 'NI',
        'short_name' => 'NIC',
        'currency' => 'Nicaraguan córdoba',
        'currency_code' => 'NIO',
        'language' => 'Spanish',
        'flag' => '🇳🇮',
      ),
      123 => 
      array (
        'name' => 'Niger',
        'country_code' => 'NE',
        'short_name' => 'NER',
        'currency' => 'West African CFA franc',
        'currency_code' => 'XOF',
        'language' => 'French',
        'flag' => '🇳🇪',
      ),
      124 => 
      array (
        'name' => 'Nigeria',
        'country_code' => 'NG',
        'short_name' => 'NGA',
        'currency' => 'Nigerian naira',
        'currency_code' => 'NGN',
        'language' => 'English',
        'flag' => '🇳🇬',
      ),
      125 => 
      array (
        'name' => 'North Korea',
        'country_code' => 'KP',
        'short_name' => 'PRK',
        'currency' => 'North Korean won',
        'currency_code' => 'KPW',
        'language' => 'Korean',
        'flag' => '🇰🇵',
      ),
      126 => 
      array (
        'name' => 'North Macedonia',
        'country_code' => 'MK',
        'short_name' => 'MKD',
        'currency' => 'Macedonian denar',
        'currency_code' => 'MKD',
        'language' => 'Macedonian',
        'flag' => '🇲🇰',
      ),
      127 => 
      array (
        'name' => 'Norway',
        'country_code' => 'NO',
        'short_name' => 'NOR',
        'currency' => 'Norwegian krone',
        'currency_code' => 'NOK',
        'language' => 'Norwegian',
        'flag' => '🇳🇴',
      ),
      128 => 
      array (
        'name' => 'Oman',
        'country_code' => 'OM',
        'short_name' => 'OMN',
        'currency' => 'Omani rial',
        'currency_code' => 'OMR',
        'language' => 'Arabic',
        'flag' => '🇴🇲',
      ),
      129 => 
      array (
        'name' => 'Pakistan',
        'country_code' => 'PK',
        'short_name' => 'PAK',
        'currency' => 'Pakistani rupee',
        'currency_code' => 'PKR',
        'language' => 'Urdu, English',
        'flag' => '🇵🇰',
      ),
      130 => 
      array (
        'name' => 'Palau',
        'country_code' => 'PW',
        'short_name' => 'PLW',
        'currency' => 'United States dollar',
        'currency_code' => 'USD',
        'language' => 'Palauan, English',
        'flag' => '🇵🇼',
      ),
      131 => 
      array (
        'name' => 'Palestine',
        'country_code' => 'PS',
        'short_name' => 'PSE',
        'currency' => 'Israeli new shekel',
        'currency_code' => 'ILS',
        'language' => 'Arabic',
        'flag' => '🇵🇸',
      ),
      132 => 
      array (
        'name' => 'Panama',
        'country_code' => 'PA',
        'short_name' => 'PAN',
        'currency' => 'Panamanian balboa, United States dollar',
        'currency_code' => 'PAB, USD',
        'language' => 'Spanish',
        'flag' => '🇵🇦',
      ),
      133 => 
      array (
        'name' => 'Papua New Guinea',
        'country_code' => 'PG',
        'short_name' => 'PNG',
        'currency' => 'Papua New Guinean kina',
        'currency_code' => 'PGK',
        'language' => 'English, Tok Pisin, Hiri Motu',
        'flag' => '🇵🇬',
      ),
      134 => 
      array (
        'name' => 'Paraguay',
        'country_code' => 'PY',
        'short_name' => 'PRY',
        'currency' => 'Paraguayan guaraní',
        'currency_code' => 'PYG',
        'language' => 'Spanish, Guaraní',
        'flag' => '🇵🇾',
      ),
      135 => 
      array (
        'name' => 'Peru',
        'country_code' => 'PE',
        'short_name' => 'PER',
        'currency' => 'Peruvian sol',
        'currency_code' => 'PEN',
        'language' => 'Spanish',
        'flag' => '🇵🇪',
      ),
      136 => 
      array (
        'name' => 'Philippines',
        'country_code' => 'PH',
        'short_name' => 'PHL',
        'currency' => 'Philippine peso',
        'currency_code' => 'PHP',
        'language' => 'Filipino, English',
        'flag' => '🇵🇭',
      ),
      137 => 
      array (
        'name' => 'Poland',
        'country_code' => 'PL',
        'short_name' => 'POL',
        'currency' => 'Polish złoty',
        'currency_code' => 'PLN',
        'language' => 'Polish',
        'flag' => '🇵🇱',
      ),
      138 => 
      array (
        'name' => 'Portugal',
        'country_code' => 'PT',
        'short_name' => 'PRT',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Portuguese',
        'flag' => '🇵🇹',
      ),
      139 => 
      array (
        'name' => 'Qatar',
        'country_code' => 'QA',
        'short_name' => 'QAT',
        'currency' => 'Qatari riyal',
        'currency_code' => 'QAR',
        'language' => 'Arabic',
        'flag' => '🇶🇦',
      ),
      140 => 
      array (
        'name' => 'Republic of the Congo',
        'country_code' => 'CG',
        'short_name' => 'COG',
        'currency' => 'Central African CFA franc',
        'currency_code' => 'XAF',
        'language' => 'French',
        'flag' => '🇨🇬',
      ),
      141 => 
      array (
        'name' => 'Romania',
        'country_code' => 'RO',
        'short_name' => 'ROU',
        'currency' => 'Romanian leu',
        'currency_code' => 'RON',
        'language' => 'Romanian',
        'flag' => '🇷🇴',
      ),
      142 => 
      array (
        'name' => 'Russia',
        'country_code' => 'RU',
        'short_name' => 'RUS',
        'currency' => 'Russian ruble',
        'currency_code' => 'RUB',
        'language' => 'Russian',
        'flag' => '🇷🇺',
      ),
      143 => 
      array (
        'name' => 'Rwanda',
        'country_code' => 'RW',
        'short_name' => 'RWA',
        'currency' => 'Rwandan franc',
        'currency_code' => 'RWF',
        'language' => 'Kinyarwanda, French, English',
        'flag' => '🇷🇼',
      ),
      144 => 
      array (
        'name' => 'Saint Kitts and Nevis',
        'country_code' => 'KN',
        'short_name' => 'KNA',
        'currency' => 'East Caribbean dollar',
        'currency_code' => 'XCD',
        'language' => 'English',
        'flag' => '🇰🇳',
      ),
      145 => 
      array (
        'name' => 'Saint Lucia',
        'country_code' => 'LC',
        'short_name' => 'LCA',
        'currency' => 'East Caribbean dollar',
        'currency_code' => 'XCD',
        'language' => 'English',
        'flag' => '🇱🇨',
      ),
      146 => 
      array (
        'name' => 'Saint Vincent and the Grenadines',
        'country_code' => 'VC',
        'short_name' => 'VCT',
        'currency' => 'East Caribbean dollar',
        'currency_code' => 'XCD',
        'language' => 'English',
        'flag' => '🇻🇨',
      ),
      147 => 
      array (
        'name' => 'Samoa',
        'country_code' => 'WS',
        'short_name' => 'WSM',
        'currency' => 'Samoan tālā',
        'currency_code' => 'WST',
        'language' => 'Samoan, English',
        'flag' => '🇼🇸',
      ),
      148 => 
      array (
        'name' => 'San Marino',
        'country_code' => 'SM',
        'short_name' => 'SMR',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Italian',
        'flag' => '🇸🇲',
      ),
      149 => 
      array (
        'name' => 'Sao Tome and Principe',
        'country_code' => 'ST',
        'short_name' => 'STP',
        'currency' => 'São Tomé and Príncipe dobra',
        'currency_code' => 'STN',
        'language' => 'Portuguese',
        'flag' => '🇸🇹',
      ),
      150 => 
      array (
        'name' => 'Saudi Arabia',
        'country_code' => 'SA',
        'short_name' => 'SAU',
        'currency' => 'Saudi riyal',
        'currency_code' => 'SAR',
        'language' => 'Arabic',
        'flag' => '🇸🇦',
      ),
      151 => 
      array (
        'name' => 'Senegal',
        'country_code' => 'SN',
        'short_name' => 'SEN',
        'currency' => 'West African CFA franc',
        'currency_code' => 'XOF',
        'language' => 'French',
        'flag' => '🇸🇳',
      ),
      152 => 
      array (
        'name' => 'Serbia',
        'country_code' => 'RS',
        'short_name' => 'SRB',
        'currency' => 'Serbian dinar',
        'currency_code' => 'RSD',
        'language' => 'Serbian',
        'flag' => '🇷🇸',
      ),
      153 => 
      array (
        'name' => 'Seychelles',
        'country_code' => 'SC',
        'short_name' => 'SYC',
        'currency' => 'Seychellois rupee',
        'currency_code' => 'SCR',
        'language' => 'French, English, Seychellois Creole',
        'flag' => '🇸🇨',
      ),
      154 => 
      array (
        'name' => 'Sierra Leone',
        'country_code' => 'SL',
        'short_name' => 'SLE',
        'currency' => 'Sierra Leonean leone',
        'currency_code' => 'SLE',
        'language' => 'English',
        'flag' => '🇸🇱',
      ),
      155 => 
      array (
        'name' => 'Singapore',
        'country_code' => 'SG',
        'short_name' => 'SGP',
        'currency' => 'Singapore dollar',
        'currency_code' => 'SGD',
        'language' => 'English, Malay, Chinese, Tamil',
        'flag' => '🇸🇬',
      ),
      156 => 
      array (
        'name' => 'Slovakia',
        'country_code' => 'SK',
        'short_name' => 'SVK',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Slovak',
        'flag' => '🇸🇰',
      ),
      157 => 
      array (
        'name' => 'Slovenia',
        'country_code' => 'SI',
        'short_name' => 'SVN',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Slovene',
        'flag' => '🇸🇮',
      ),
      158 => 
      array (
        'name' => 'Solomon Islands',
        'country_code' => 'SB',
        'short_name' => 'SLB',
        'currency' => 'Solomon Islands dollar',
        'currency_code' => 'SBD',
        'language' => 'English',
        'flag' => '🇸🇧',
      ),
      159 => 
      array (
        'name' => 'Somalia',
        'country_code' => 'SO',
        'short_name' => 'SOM',
        'currency' => 'Somali shilling',
        'currency_code' => 'SOS',
        'language' => 'Somali, Arabic',
        'flag' => '🇸🇴',
      ),
      160 => 
      array (
        'name' => 'South Africa',
        'country_code' => 'ZA',
        'short_name' => 'ZAF',
        'currency' => 'South African rand',
        'currency_code' => 'ZAR',
        'language' => 'Zulu, Xhosa, Afrikaans, English, Northern Sotho, Tswana, Sesotho, Tsonga, Swati, Venda, Southern Ndebele',
        'flag' => '🇿🇦',
      ),
      161 => 
      array (
        'name' => 'South Korea',
        'country_code' => 'KR',
        'short_name' => 'KOR',
        'currency' => 'South Korean won',
        'currency_code' => 'KRW',
        'language' => 'Korean',
        'flag' => '🇰🇷',
      ),
      162 => 
      array (
        'name' => 'South Sudan',
        'country_code' => 'SS',
        'short_name' => 'SSD',
        'currency' => 'South Sudanese pound',
        'currency_code' => 'SSP',
        'language' => 'English',
        'flag' => '🇸🇸',
      ),
      163 => 
      array (
        'name' => 'Spain',
        'country_code' => 'ES',
        'short_name' => 'ESP',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Spanish',
        'flag' => '🇪🇸',
      ),
      164 => 
      array (
        'name' => 'Sri Lanka',
        'country_code' => 'LK',
        'short_name' => 'LKA',
        'currency' => 'Sri Lankan rupee',
        'currency_code' => 'LKR',
        'language' => 'Sinhala, Tamil',
        'flag' => '🇱🇰',
      ),
      165 => 
      array (
        'name' => 'Sudan',
        'country_code' => 'SD',
        'short_name' => 'SDN',
        'currency' => 'Sudanese pound',
        'currency_code' => 'SDG',
        'language' => 'Arabic, English',
        'flag' => '🇸🇩',
      ),
      166 => 
      array (
        'name' => 'Suriname',
        'country_code' => 'SR',
        'short_name' => 'SUR',
        'currency' => 'Surinamese dollar',
        'currency_code' => 'SRD',
        'language' => 'Dutch',
        'flag' => '🇸🇷',
      ),
      167 => 
      array (
        'name' => 'Sweden',
        'country_code' => 'SE',
        'short_name' => 'SWE',
        'currency' => 'Swedish krona',
        'currency_code' => 'SEK',
        'language' => 'Swedish',
        'flag' => '🇸🇪',
      ),
      168 => 
      array (
        'name' => 'Switzerland',
        'country_code' => 'CH',
        'short_name' => 'CHE',
        'currency' => 'Swiss franc',
        'currency_code' => 'CHF',
        'language' => 'German, French, Italian, Romansh',
        'flag' => '🇨🇭',
      ),
      169 => 
      array (
        'name' => 'Syria',
        'country_code' => 'SY',
        'short_name' => 'SYR',
        'currency' => 'Syrian pound',
        'currency_code' => 'SYP',
        'language' => 'Arabic',
        'flag' => '🇸🇾',
      ),
      170 => 
      array (
        'name' => 'Taiwan',
        'country_code' => 'TW',
        'short_name' => 'TWN',
        'currency' => 'New Taiwan dollar',
        'currency_code' => 'TWD',
        'language' => 'Mandarin Chinese',
        'flag' => '🇹🇼',
      ),
      171 => 
      array (
        'name' => 'Tajikistan',
        'country_code' => 'TJ',
        'short_name' => 'TJK',
        'currency' => 'Tajikistani somoni',
        'currency_code' => 'TJS',
        'language' => 'Tajik',
        'flag' => '🇹🇯',
      ),
      172 => 
      array (
        'name' => 'Tanzania',
        'country_code' => 'TZ',
        'short_name' => 'TZA',
        'currency' => 'Tanzanian shilling',
        'currency_code' => 'TZS',
        'language' => 'Swahili, English',
        'flag' => '🇹🇿',
      ),
      173 => 
      array (
        'name' => 'Thailand',
        'country_code' => 'TH',
        'short_name' => 'THA',
        'currency' => 'Thai baht',
        'currency_code' => 'THB',
        'language' => 'Thai',
        'flag' => '🇹🇭',
      ),
      174 => 
      array (
        'name' => 'Timor-Leste (East Timor)',
        'country_code' => 'TL',
        'short_name' => 'TLS',
        'currency' => 'United States dollar',
        'currency_code' => 'USD',
        'language' => 'Tetum, Portuguese',
        'flag' => '🇹🇱',
      ),
      175 => 
      array (
        'name' => 'Togo',
        'country_code' => 'TG',
        'short_name' => 'TGO',
        'currency' => 'West African CFA franc',
        'currency_code' => 'XOF',
        'language' => 'French',
        'flag' => '🇹🇬',
      ),
      176 => 
      array (
        'name' => 'Tonga',
        'country_code' => 'TO',
        'short_name' => 'TON',
        'currency' => 'Tongan paʻanga',
        'currency_code' => 'TOP',
        'language' => 'Tongan, English',
        'flag' => '🇹🇴',
      ),
      177 => 
      array (
        'name' => 'Trinidad and Tobago',
        'country_code' => 'TT',
        'short_name' => 'TTO',
        'currency' => 'Trinidad and Tobago dollar',
        'currency_code' => 'TTD',
        'language' => 'English',
        'flag' => '🇹🇹',
      ),
      178 => 
      array (
        'name' => 'Tunisia',
        'country_code' => 'TN',
        'short_name' => 'TUN',
        'currency' => 'Tunisian dinar',
        'currency_code' => 'TND',
        'language' => 'Arabic',
        'flag' => '🇹🇳',
      ),
      179 => 
      array (
        'name' => 'Turkey',
        'country_code' => 'TR',
        'short_name' => 'TUR',
        'currency' => 'Turkish lira',
        'currency_code' => 'TRY',
        'language' => 'Turkish',
        'flag' => '🇹🇷',
      ),
      180 => 
      array (
        'name' => 'Turkmenistan',
        'country_code' => 'TM',
        'short_name' => 'TKM',
        'currency' => 'Turkmenistan manat',
        'currency_code' => 'TMT',
        'language' => 'Turkmen',
        'flag' => '🇹🇲',
      ),
      181 => 
      array (
        'name' => 'Tuvalu',
        'country_code' => 'TV',
        'short_name' => 'TUV',
        'currency' => 'Australian dollar',
        'currency_code' => 'AUD',
        'language' => 'Tuvaluan, English',
        'flag' => '🇹🇻',
      ),
      182 => 
      array (
        'name' => 'Uganda',
        'country_code' => 'UG',
        'short_name' => 'UGA',
        'currency' => 'Ugandan shilling',
        'currency_code' => 'UGX',
        'language' => 'English, Swahili',
        'flag' => '🇺🇬',
      ),
      183 => 
      array (
        'name' => 'Ukraine',
        'country_code' => 'UA',
        'short_name' => 'UKR',
        'currency' => 'Ukrainian hryvnia',
        'currency_code' => 'UAH',
        'language' => 'Ukrainian',
        'flag' => '🇺🇦',
      ),
      184 => 
      array (
        'name' => 'United Arab Emirates',
        'country_code' => 'AE',
        'short_name' => 'ARE',
        'currency' => 'United Arab Emirates dirham',
        'currency_code' => 'AED',
        'language' => 'Arabic',
        'flag' => '🇦🇪',
      ),
      185 => 
      array (
        'name' => 'United Kingdom',
        'country_code' => 'GB',
        'short_name' => 'GBR',
        'currency' => 'Pound sterling',
        'currency_code' => 'GBP',
        'language' => 'English',
        'flag' => '🇬🇧',
      ),
      186 => 
      array (
        'name' => 'United States',
        'country_code' => 'US',
        'short_name' => 'USA',
        'currency' => 'United States dollar',
        'currency_code' => 'USD',
        'language' => 'English',
        'flag' => '🇺🇸',
      ),
      187 => 
      array (
        'name' => 'Uruguay',
        'country_code' => 'UY',
        'short_name' => 'URY',
        'currency' => 'Uruguayan peso',
        'currency_code' => 'UYU',
        'language' => 'Spanish',
        'flag' => '🇺🇾',
      ),
      188 => 
      array (
        'name' => 'Uzbekistan',
        'country_code' => 'UZ',
        'short_name' => 'UZB',
        'currency' => 'Uzbekistani soʻm',
        'currency_code' => 'UZS',
        'language' => 'Uzbek',
        'flag' => '🇺🇿',
      ),
      189 => 
      array (
        'name' => 'Vanuatu',
        'country_code' => 'VU',
        'short_name' => 'VUT',
        'currency' => 'Vanuatu vatu',
        'currency_code' => 'VUV',
        'language' => 'Bislama, English, French',
        'flag' => '🇻🇺',
      ),
      190 => 
      array (
        'name' => 'Vatican City',
        'country_code' => 'VA',
        'short_name' => 'VAT',
        'currency' => 'Euro',
        'currency_code' => 'EUR',
        'language' => 'Italian',
        'flag' => '🇻🇦',
      ),
      191 => 
      array (
        'name' => 'Venezuela',
        'country_code' => 'VE',
        'short_name' => 'VEN',
        'currency' => 'Venezuelan bolívar',
        'currency_code' => 'VES',
        'language' => 'Spanish',
        'flag' => '🇻🇪',
      ),
      192 => 
      array (
        'name' => 'Vietnam',
        'country_code' => 'VN',
        'short_name' => 'VNM',
        'currency' => 'Vietnamese đồng',
        'currency_code' => 'VND',
        'language' => 'Vietnamese',
        'flag' => '🇻🇳',
      ),
      193 => 
      array (
        'name' => 'Yemen',
        'country_code' => 'YE',
        'short_name' => 'YEM',
        'currency' => 'Yemeni rial',
        'currency_code' => 'YER',
        'language' => 'Arabic',
        'flag' => '🇾🇪',
      ),
      194 => 
      array (
        'name' => 'Zambia',
        'country_code' => 'ZM',
        'short_name' => 'ZMB',
        'currency' => 'Zambian kwacha',
        'currency_code' => 'ZMW',
        'language' => 'English',
        'flag' => '🇿🇲',
      ),
      195 => 
      array (
        'name' => 'Zimbabwe',
        'country_code' => 'ZW',
        'short_name' => 'ZWE',
        'currency' => 'United States dollar',
        'currency_code' => 'USD',
        'language' => 'English, Shona, Sindebele',
        'flag' => '🇿🇼',
      ),
    ),
    'currency' => 
    array (
      'AFN' => '؋',
      'ALL' => 'L',
      'DZD' => 'د.ج',
      'USD' => '$',
      'AOA' => 'Kz',
      'XCD' => '$',
      'ARS' => '$',
      'AMD' => '֏',
      'AWG' => 'ƒ',
      'AUD' => '$',
      'AZN' => '₼',
      'BSD' => '$',
      'BHD' => '.د.ب',
      'BDT' => '৳',
      'BBD' => '$',
      'BYN' => 'Br',
      'EUR' => '€',
      'BZD' => '$',
      'XOF' => 'Fr',
      'BMD' => '$',
      'BTN' => 'Nu.',
      'INR' => '₹',
      'BOB' => 'Bs.',
      'BOV' => 'BOV',
      'BAM' => 'KM',
      'BWP' => 'P',
      'BRL' => 'R$',
      'BND' => '$',
      'BGN' => 'лв',
      'BIF' => 'Fr',
      'CVE' => '$',
      'KHR' => '៛',
      'XAF' => 'Fr',
      'CAD' => '$',
      'KYD' => '$',
      'CLP' => '$',
      'CLF' => 'UF',
      'CNY' => '¥',
      'COP' => '$',
      'COU' => 'COU',
      'KMF' => 'Fr',
      'CDF' => 'Fr',
      'NZD' => '$',
      'CRC' => '₡',
      'HRK' => 'kn',
      'CUP' => '$',
      'CUC' => '$',
      'ANG' => 'ƒ',
      'CZK' => 'Kč',
      'DKK' => 'kr',
      'DJF' => 'Fr',
      'DOP' => '$',
      'EGP' => '£',
      'SVC' => '$',
      'ERN' => 'Nfk',
      'SZL' => 'L',
      'ETB' => 'Br',
      'FKP' => '£',
      'FJD' => '$',
      'GMD' => 'D',
      'GEL' => '₾',
      'GHS' => '₵',
      'GIP' => '£',
      'GTQ' => 'Q',
      'GBP' => '£',
      'GNF' => 'Fr',
      'GYD' => '$',
      'HTG' => 'G',
      'HNL' => 'L',
      'HKD' => '$',
      'HUF' => 'Ft',
      'ISK' => 'kr',
      'IDR' => 'Rp',
      'IRR' => '﷼',
      'IQD' => 'ع.د',
      'ILS' => '₪',
      'JMD' => '$',
      'JPY' => '¥',
      'JOD' => 'د.ا',
      'KZT' => '₸',
      'KES' => 'Sh',
      'KPW' => '₩',
      'KRW' => '₩',
      'KWD' => 'د.ك',
      'KGS' => 'сом',
      'LAK' => '₭',
      'LBP' => 'ل.ل',
      'LSL' => 'L',
      'LRD' => '$',
      'LYD' => 'ل.د',
      'MOP' => 'MOP$',
      'MKD' => 'ден',
      'MGA' => 'Ar',
      'MWK' => 'MK',
      'MYR' => 'RM',
      'MVR' => '.ރ',
      'MRU' => 'UM',
      'MUR' => '₨',
      'MXN' => '$',
      'MXV' => 'MXV',
      'MDL' => 'L',
      'MNT' => '₮',
      'MAD' => 'د.م.',
      'MZN' => 'MT',
      'MMK' => 'Ks',
      'NAD' => '$',
      'NPR' => '₨',
      'NIO' => 'C$',
      'NGN' => '₦',
      'OMR' => 'ر.ع.',
      'PKR' => '₨',
      'PAB' => 'B/.',
      'PGK' => 'K',
      'PYG' => '₲',
      'PEN' => 'S/',
      'PHP' => '₱',
      'PLN' => 'zł',
      'QAR' => 'ر.ق',
      'RON' => 'lei',
      'RUB' => '₽',
      'RWF' => 'Fr',
      'SHP' => '£',
      'WST' => 'T',
      'STN' => 'Db',
      'SAR' => 'ر.س',
      'RSD' => 'дин',
      'SCR' => '₨',
      'SLL' => 'Le',
      'SGD' => '$',
      'SBD' => '$',
      'SOS' => 'Sh',
      'ZAR' => 'R',
      'SSP' => '£',
      'LKR' => 'Rs',
      'SDG' => 'ج.س.',
      'SRD' => '$',
      'SEK' => 'kr',
      'CHF' => 'Fr',
      'SYP' => 'ل.س',
      'TWD' => 'NT$',
      'TJS' => 'ЅМ',
      'TZS' => 'Sh',
      'THB' => '฿',
      'TOP' => 'T$',
      'TTD' => '$',
      'TND' => 'د.ت',
      'TRY' => '₺',
      'TMT' => 'm',
      'UGX' => 'Sh',
      'UAH' => '₴',
      'AED' => 'د.إ',
      'UYU' => '$',
      'UZS' => 'сўм',
      'VUV' => 'Vt',
      'VES' => 'Bs.S',
      'VND' => '₫',
      'YER' => '﷼',
      'ZMW' => 'ZK',
    ),
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'hotel_booking',
        'prefix' => '',
        'foreign_key_constraints' => true,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'hotel_booking',
        'username' => 'root',
        'password' => 'password',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'mariadb' => 
      array (
        'driver' => 'mariadb',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'hotel_booking',
        'username' => 'root',
        'password' => 'password',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'hotel_booking',
        'username' => 'root',
        'password' => 'password',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'search_path' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'hotel_booking',
        'username' => 'root',
        'password' => 'password',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 
    array (
      'table' => 'migrations',
      'update_date_on_publish' => true,
    ),
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'laravel_database_',
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
      ),
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => '/Volumes/Development/projects/oystay/hotel-booking/storage/app',
        'throw' => false,
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => '/Volumes/Development/projects/oystay/hotel-booking/storage/app/public',
        'url' => 'http://localhost/storage',
        'visibility' => 'public',
        'throw' => false,
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'bucket' => '',
        'url' => NULL,
        'endpoint' => NULL,
        'use_path_style_endpoint' => false,
        'throw' => false,
      ),
    ),
    'links' => 
    array (
      '/Volumes/Development/projects/oystay/hotel-booking/public/storage' => '/Volumes/Development/projects/oystay/hotel-booking/storage/app/public',
    ),
  ),
  'honeypot' => 
  array (
    'enabled' => true,
    'name_field_name' => 'hotel_booking',
    'randomize_name_field_name' => true,
    'valid_from_timestamp' => true,
    'valid_from_field_name' => 'hotel_booking_form',
    'amount_of_seconds' => 5,
    'respond_to_spam_with' => 'Spatie\\Honeypot\\SpamResponder\\BlankPageResponder',
    'honeypot_fields_required_for_all_forms' => false,
    'spam_protection' => 'Spatie\\Honeypot\\SpamProtection',
    'with_csp' => false,
  ),
  'jwt' => 
  array (
    'secret' => NULL,
    'keys' => 
    array (
      'public' => NULL,
      'private' => NULL,
      'passphrase' => NULL,
    ),
    'ttl' => 60,
    'refresh_iat' => false,
    'refresh_ttl' => 20160,
    'algo' => 'HS256',
    'required_claims' => 
    array (
      0 => 'iss',
      1 => 'iat',
      2 => 'exp',
      3 => 'nbf',
      4 => 'sub',
      5 => 'jti',
    ),
    'persistent_claims' => 
    array (
    ),
    'lock_subject' => true,
    'leeway' => 0,
    'blacklist_enabled' => true,
    'blacklist_grace_period' => 0,
    'show_black_list_exception' => true,
    'decrypt_cookies' => false,
    'cookie_key_name' => 'token',
    'providers' => 
    array (
      'jwt' => 'PHPOpenSourceSaver\\JWTAuth\\Providers\\JWT\\Lcobucci',
      'auth' => 'PHPOpenSourceSaver\\JWTAuth\\Providers\\Auth\\Illuminate',
      'storage' => 'PHPOpenSourceSaver\\JWTAuth\\Providers\\Storage\\Illuminate',
    ),
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'deprecations' => 
    array (
      'channel' => NULL,
      'trace' => false,
    ),
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => '/Volumes/Development/projects/oystay/hotel-booking/storage/logs/laravel.log',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => '/Volumes/Development/projects/oystay/hotel-booking/storage/logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
        'replace_placeholders' => true,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
          'connectionString' => 'tls://:',
        ),
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
        'facility' => 8,
        'replace_placeholders' => true,
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => '/Volumes/Development/projects/oystay/hotel-booking/storage/logs/laravel.log',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'log',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '2525',
        'encryption' => NULL,
        'username' => NULL,
        'password' => NULL,
        'timeout' => NULL,
        'local_domain' => 'localhost',
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'resend' => 
      array (
        'transport' => 'resend',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs -i',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
      'failover' => 
      array (
        'transport' => 'failover',
        'mailers' => 
        array (
          0 => 'smtp',
          1 => 'log',
        ),
      ),
      'roundrobin' => 
      array (
        'transport' => 'roundrobin',
        'mailers' => 
        array (
          0 => 'ses',
          1 => 'postmark',
        ),
      ),
    ),
    'from' => 
    array (
      'address' => 'hello@example.com',
      'name' => 'Laravel',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => '/Volumes/Development/projects/oystay/hotel-booking/resources/views/vendor/mail',
      ),
    ),
  ),
  'notify' => 
  array (
    'theme' => 'light',
    'timeout' => 5000,
    'preset-messages' => 
    array (
      'user-updated' => 
      array (
        'message' => 'The user has been updated successfully.',
        'type' => 'success',
        'model' => 'connect',
        'title' => 'User Updated',
      ),
    ),
  ),
  'permission' => 
  array (
    'models' => 
    array (
      'permission' => 'Spatie\\Permission\\Models\\Permission',
      'role' => 'Spatie\\Permission\\Models\\Role',
    ),
    'table_names' => 
    array (
      'roles' => 'roles',
      'permissions' => 'permissions',
      'model_has_permissions' => 'model_has_permissions',
      'model_has_roles' => 'model_has_roles',
      'role_has_permissions' => 'role_has_permissions',
    ),
    'column_names' => 
    array (
      'role_pivot_key' => NULL,
      'permission_pivot_key' => NULL,
      'model_morph_key' => 'model_id',
      'team_foreign_key' => 'team_id',
    ),
    'register_permission_check_method' => true,
    'register_octane_reset_listener' => false,
    'events_enabled' => false,
    'teams' => false,
    'team_resolver' => 'Spatie\\Permission\\DefaultTeamResolver',
    'use_passport_client_credentials' => false,
    'display_permission_in_exception' => false,
    'display_role_in_exception' => false,
    'enable_wildcard_permission' => false,
    'cache' => 
    array (
      'expiration_time' => 
      \DateInterval::__set_state(array(
         'from_string' => true,
         'date_string' => '24 hours',
      )),
      'key' => 'spatie.permission.cache',
      'store' => 'default',
    ),
  ),
  'queue' => 
  array (
    'default' => 'database',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'connection' => NULL,
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
        'after_commit' => false,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
        'after_commit' => false,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'default',
        'suffix' => NULL,
        'region' => 'us-east-1',
        'after_commit' => false,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
        'after_commit' => false,
      ),
    ),
    'batching' => 
    array (
      'database' => 'mysql',
      'table' => 'job_batches',
    ),
    'failed' => 
    array (
      'driver' => 'database-uuids',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'reverb' => 
  array (
    'default' => 'reverb',
    'servers' => 
    array (
      'reverb' => 
      array (
        'host' => '0.0.0.0',
        'port' => 8080,
        'path' => '',
        'hostname' => 'localhost',
        'options' => 
        array (
          'tls' => 
          array (
          ),
        ),
        'max_request_size' => 10000,
        'scaling' => 
        array (
          'enabled' => false,
          'channel' => 'reverb',
          'server' => 
          array (
            'url' => NULL,
            'host' => '127.0.0.1',
            'port' => '6379',
            'username' => NULL,
            'password' => NULL,
            'database' => '0',
            'timeout' => 60,
          ),
        ),
        'pulse_ingest_interval' => 15,
        'telescope_ingest_interval' => 15,
      ),
    ),
    'apps' => 
    array (
      'provider' => 'config',
      'apps' => 
      array (
        0 => 
        array (
          'key' => 'b1b4sibelyrmvpcyearl',
          'secret' => 'te9xt7arhdyfnelvuvvf',
          'app_id' => '885000',
          'options' => 
          array (
            'host' => 'localhost',
            'port' => '8080',
            'scheme' => 'http',
            'useTLS' => false,
          ),
          'allowed_origins' => 
          array (
            0 => '*',
          ),
          'ping_interval' => 60,
          'activity_timeout' => 30,
          'max_connections' => NULL,
          'max_message_size' => 10000,
          'accept_client_events_from' => 'members',
          'rate_limiting' => 
          array (
            'enabled' => false,
            'max_attempts' => 60,
            'decay_seconds' => 60,
            'terminate_on_limit' => false,
          ),
        ),
      ),
    ),
  ),
  'sanctum' => 
  array (
    'stateful' => 
    array (
      0 => 'hotel-booking.test:5173',
      1 => 'hotel-booking.test:8000',
    ),
    'guard' => 
    array (
      0 => 'web',
    ),
    'expiration' => NULL,
    'token_prefix' => '',
    'middleware' => 
    array (
      'authenticate_session' => 'Laravel\\Sanctum\\Http\\Middleware\\AuthenticateSession',
      'encrypt_cookies' => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
      'validate_csrf_token' => 'Illuminate\\Foundation\\Http\\Middleware\\ValidateCsrfToken',
    ),
  ),
  'services' => 
  array (
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
    'resend' => 
    array (
      'key' => NULL,
    ),
    'slack' => 
    array (
      'notifications' => 
      array (
        'bot_user_oauth_token' => NULL,
        'channel' => NULL,
      ),
    ),
    'facebook' => 
    array (
      'client_id' => '882634440564074',
      'client_secret' => 'e3fb182df80f0f202ab348e8aa003530',
      'redirect' => 'http://localhost/api/auth/facebook/callback',
    ),
    'google' => 
    array (
      'client_id' => '81223814754-jbj267ei4hnvr03bb533gonhq1pn44mr.apps.googleusercontent.com',
      'client_secret' => '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',
      'redirect' => 'http://localhost/api/auth/google/callback',
    ),
  ),
  'session' => 
  array (
    'driver' => 'database',
    'lifetime' => '120',
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => '/Volumes/Development/projects/oystay/hotel-booking/storage/framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'laravel_session',
    'path' => '/',
    'domain' => 'hotel-booking.test',
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
    'partitioned' => false,
  ),
  'site' => 
  array (
    'site_info' => 
    array (
      'name' => 'Laravel',
      'address' => '123 Main St',
      'city' => 'Springfield',
      'state' => 'IL',
      'zip' => '62701',
      'phone' => '217-555-5555',
      'email' => 'site@gmail.com',
    ),
    'developed_by' => 
    array (
      'company' => 'Infinity Flame Soft',
      'company_website' => 'https://infinityflamesoft.com/',
    ),
    'portal_filter_not_exists' => 
    array (
      0 => '/',
    ),
    'assets' => 
    array (
      'admin' => 
      array (
        'css' => 
        array (
          0 => 
          array (
            'src' => 'https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700',
            'type' => 'cdn',
            'rel' => 'stylesheet',
          ),
          1 => 
          array (
            'src' => 'nucleo-icons.css',
            'type' => 'local',
            'rel' => 'stylesheet',
          ),
          2 => 
          array (
            'src' => 'nucleo-svg.css',
            'type' => 'local',
            'rel' => 'stylesheet',
          ),
          3 => 
          array (
            'src' => 'nucleo-svg.css',
            'type' => 'local',
            'rel' => 'stylesheet',
          ),
          4 => 
          array (
            'src' => 'argon-dashboard.css',
            'type' => 'local',
            'rel' => 'stylesheet',
            'id' => 'pagestyle',
          ),
          5 => 
          array (
            'src' => 'select2.min.css',
            'type' => 'local',
            'rel' => 'stylesheet',
          ),
          6 => 
          array (
            'src' => 'toastr.css',
            'type' => 'local',
            'rel' => 'stylesheet',
          ),
          7 => 
          array (
            'src' => 'custom.css',
            'type' => 'local',
            'rel' => 'stylesheet',
          ),
        ),
        'js' => 
        array (
          0 => 
          array (
            'src' => 'plugins/jquery-3.7.1.min.js',
            'type' => 'local',
          ),
          1 => 
          array (
            'src' => 'core/popper.min.js',
            'type' => 'local',
          ),
          2 => 
          array (
            'src' => 'core/bootstrap.min.js',
            'type' => 'local',
          ),
          3 => 
          array (
            'src' => 'https://kit.fontawesome.com/42d5adcbca.js',
            'type' => 'cdn',
          ),
          4 => 
          array (
            'src' => 'plugins/perfect-scrollbar.min.js',
            'type' => 'local',
          ),
          5 => 
          array (
            'src' => 'plugins/smooth-scrollbar.min.js',
            'type' => 'local',
          ),
          6 => 
          array (
            'src' => 'plugins/dragula/dragula.min.js',
            'type' => 'local',
          ),
          7 => 
          array (
            'src' => 'plugins/jkanban/jkanban.js',
            'type' => 'local',
          ),
          8 => 
          array (
            'src' => 'plugins/chartjs.min.js',
            'type' => 'local',
          ),
          9 => 
          array (
            'src' => 'customs/chart.js',
            'type' => 'local',
          ),
          10 => 
          array (
            'src' => 'customs/sidebar.js',
            'type' => 'local',
          ),
          11 => 
          array (
            'src' => 'plugins/sweetalert.min.js',
            'type' => 'local',
          ),
          12 => 
          array (
            'src' => 'https://buttons.github.io/buttons.js',
            'type' => 'cdn',
          ),
          13 => 
          array (
            'src' => 'argon-dashboard.min.js',
            'type' => 'local',
          ),
          14 => 
          array (
            'src' => 'plugins/select2.min.js',
            'type' => 'local',
          ),
          15 => 
          array (
            'src' => 'plugins/toastr.min.js',
            'type' => 'local',
          ),
          16 => 
          array (
            'src' => 'customs/custom.js',
            'type' => 'local',
          ),
        ),
      ),
      'portal' => 
      array (
        'css' => 
        array (
          0 => 
          array (
            'src' => 'bootstrap.min.css',
            'type' => 'local',
            'rel' => 'stylesheet',
          ),
          1 => 
          array (
            'src' => 'jquery-ui.css',
            'type' => 'local',
            'rel' => 'stylesheet',
          ),
          2 => 
          array (
            'src' => 'style.css',
            'type' => 'local',
            'rel' => 'stylesheet',
          ),
          3 => 
          array (
            'src' => 'responsive.css',
            'type' => 'local',
            'rel' => 'stylesheet',
          ),
          4 => 
          array (
            'src' => 'custom.css',
            'type' => 'local',
            'rel' => 'stylesheet',
          ),
        ),
        'js' => 
        array (
          0 => 
          array (
            'src' => 'jquery.min.js',
            'type' => 'local',
          ),
          1 => 
          array (
            'src' => 'bootstrap.bundle.min.js',
            'type' => 'local',
          ),
          2 => 
          array (
            'src' => 'jquery.easing.min.js',
            'type' => 'local',
          ),
          3 => 
          array (
            'src' => 'jquery-ui.js',
            'type' => 'local',
          ),
          4 => 
          array (
            'src' => 'main.js',
            'type' => 'local',
          ),
        ),
      ),
    ),
    'sidebar' => 
    array (
      'items' => 
      array (
        0 => 
        array (
          'name' => 'Dashboard',
          'route' => 'admin.dashboard',
          'icon' => 'ni ni-shop text-primary',
          'key' => 'admin/dashboard*',
          'permission' => 'can_view_dashboard',
          'children' => 
          array (
          ),
        ),
        1 => 
        array (
          'name' => 'Bookings',
          'route' => NULL,
          'icon' => 'ni ni-shop text-primary',
          'key' => 'admin/bookings*',
          'permission' => 'can_view_booking',
          'children' => 
          array (
            0 => 
            array (
              'name' => 'Bookings',
              'route' => 'admin.bookings.index',
              'icon' => 'ni ni-building text-default',
              'key' => 'admin/bookings',
              'permission' => 'can_view_booking',
              'children' => 
              array (
              ),
            ),
            1 => 
            array (
              'name' => 'Requests',
              'route' => 'admin.bookings.request.index',
              'icon' => 'ni ni-building text-default',
              'key' => 'admin/bookings/request',
              'permission' => 'can_view_booking_request',
              'children' => 
              array (
              ),
            ),
          ),
        ),
        2 => 
        array (
          'name' => 'Rooms',
          'route' => NULL,
          'icon' => 'fa fa-bed text-primary',
          'key' => 'admin/rooms*',
          'permission' => 'can_view_rooms',
          'children' => 
          array (
            0 => 
            array (
              'name' => 'Rooms',
              'route' => 'admin.rooms.index',
              'icon' => 'ni ni-building text-default',
              'key' => 'admin/rooms',
              'permission' => 'can_view_room',
              'children' => 
              array (
              ),
            ),
            1 => 
            array (
              'name' => 'Room Types',
              'route' => 'admin.rooms.room-types.index',
              'icon' => 'ni ni-building text-default',
              'key' => 'admin/rooms/room-types',
              'permission' => 'can_view_room_type',
              'children' => 
              array (
              ),
            ),
            2 => 
            array (
              'name' => 'Bed Types',
              'route' => 'admin.rooms.bed-types.index',
              'icon' => 'ni ni-building text-default',
              'key' => 'admin/rooms/bed-types',
              'permission' => 'can_view_bed_type',
              'children' => 
              array (
              ),
            ),
            3 => 
            array (
              'name' => 'Price Types',
              'route' => 'admin.rooms.price-types.index',
              'icon' => 'ni ni-building text-default',
              'key' => 'admin/rooms/price-types',
              'permission' => 'can_view_price_type',
              'children' => 
              array (
              ),
            ),
          ),
        ),
        3 => 
        array (
          'name' => 'Properties',
          'route' => NULL,
          'icon' => 'ni ni-building text-primary',
          'key' => 'admin/properties*',
          'permission' => 'can_view_properties',
          'children' => 
          array (
            0 => 
            array (
              'name' => 'Property Rules',
              'route' => 'admin.properties.rules.index',
              'icon' => 'ni ni-building text-default',
              'key' => 'admin/properties/rules',
              'permission' => 'can_view_property_rule',
              'children' => 
              array (
              ),
            ),
            1 => 
            array (
              'name' => 'Properties',
              'route' => 'admin.properties.index',
              'icon' => 'ni ni-building text-default',
              'key' => 'admin/properties',
              'permission' => 'can_view_property',
              'children' => 
              array (
              ),
            ),
            2 => 
            array (
              'name' => 'Property Categories',
              'route' => 'admin.properties.categories.index',
              'icon' => 'ni ni-building text-default',
              'key' => 'admin/properties/property-categories',
              'permission' => 'can_view_property_category',
              'children' => 
              array (
              ),
            ),
          ),
        ),
        4 => 
        array (
          'name' => 'Reviews',
          'route' => NULL,
          'icon' => 'fa fa-star text-primary',
          'key' => 'admin/reviews*',
          'permission' => 'can_view_review',
          'children' => 
          array (
            0 => 
            array (
              'name' => 'Reviews',
              'route' => 'admin.reviews.index',
              'icon' => 'ni ni-building text-default',
              'key' => 'admin/reviews',
              'permission' => 'can_view_review',
              'children' => 
              array (
              ),
            ),
            1 => 
            array (
              'name' => 'Categories',
              'route' => 'admin.reviews.categories.index',
              'icon' => 'ni ni-building text-default',
              'key' => 'admin/reviews/categories',
              'permission' => 'can_view_review_category',
              'children' => 
              array (
              ),
            ),
          ),
        ),
        5 => 
        array (
          'name' => 'Facilities',
          'route' => NULL,
          'icon' => 'ni ni-support-16 text-primary',
          'key' => 'admin/facilities*',
          'permission' => 'can_view_facilities',
          'children' => 
          array (
            0 => 
            array (
              'name' => 'Sub Facilities',
              'route' => 'admin.facilities.sub-facilities.index',
              'icon' => 'ni ni-building text-default',
              'key' => 'admin/facilities/sub-facilities',
              'permission' => 'can_view_sub_facility',
              'children' => 
              array (
              ),
            ),
            1 => 
            array (
              'name' => 'Facilities',
              'route' => 'admin.facilities.index',
              'icon' => 'ni ni-building text-default',
              'key' => 'admin/facilities',
              'permission' => 'can_view_facility',
              'children' => 
              array (
              ),
            ),
          ),
        ),
        6 => 
        array (
          'name' => 'Surroundings',
          'route' => NULL,
          'icon' => 'ni ni-map-big text-primary',
          'key' => 'admin/surroundings*',
          'permission' => 'can_view_surroundings',
          'children' => 
          array (
            0 => 
            array (
              'name' => 'Surrounding Places',
              'route' => 'admin.surroundings.surrounding-places.index',
              'icon' => 'ni ni-world text-default',
              'key' => 'admin/surroundings/surrounding-places',
              'permission' => 'can_view_surrounding_place',
              'children' => 
              array (
              ),
            ),
            1 => 
            array (
              'name' => 'Surroundings',
              'route' => 'admin.surroundings.index',
              'icon' => 'ni ni-world text-default',
              'key' => 'admin/surroundings',
              'permission' => 'can_view_surrounding',
              'children' => 
              array (
              ),
            ),
          ),
        ),
        7 => 
        array (
          'name' => 'Locations',
          'route' => NULL,
          'icon' => 'ni ni-world text-primary',
          'key' => 'admin/places*',
          'permission' => 'can_view_locations',
          'children' => 
          array (
            0 => 
            array (
              'name' => 'Places',
              'route' => 'admin.places.index',
              'icon' => 'ni ni-world text-default',
              'key' => 'admin/places',
              'permission' => 'can_view_place',
              'children' => 
              array (
              ),
            ),
            1 => 
            array (
              'name' => 'Cities',
              'route' => 'admin.places.cities.index',
              'icon' => 'ni ni-world text-default',
              'key' => 'admin/places/cities',
              'permission' => 'can_view_city',
              'children' => 
              array (
              ),
            ),
            2 => 
            array (
              'name' => 'States',
              'route' => 'admin.places.states.index',
              'icon' => 'ni ni-world text-default',
              'key' => 'admin/places/states',
              'permission' => 'can_view_state',
              'children' => 
              array (
              ),
            ),
            3 => 
            array (
              'name' => 'Countries',
              'route' => 'admin.places.countries.index',
              'icon' => 'ni ni-world text-default',
              'key' => 'admin/places/countries',
              'permission' => 'can_view_country',
              'children' => 
              array (
              ),
            ),
          ),
        ),
        8 => 
        array (
          'name' => 'Access Control',
          'route' => NULL,
          'icon' => 'ni ni-key-25 text-info',
          'key' => 'admin/acl*',
          'permission' => 'can_view_acl',
          'children' => 
          array (
            0 => 
            array (
              'name' => 'Roles',
              'route' => 'admin.acl.roles.index',
              'icon' => 'ni ni-circle-08 text-default',
              'key' => 'admin/acl/roles',
              'permission' => 'can_view_acl_role',
              'children' => 
              array (
              ),
            ),
            1 => 
            array (
              'name' => 'Permissions',
              'route' => 'admin.acl.permissions.index',
              'icon' => 'ni ni-lock-circle-open text-default',
              'permission' => 'can_view_acl_permission',
              'key' => 'admin/acl/permissions',
            ),
            2 => 
            array (
              'name' => 'Users',
              'route' => 'admin.acl.users.index',
              'icon' => 'ni ni-single-02 text-default',
              'key' => 'admin/acl/users',
              'permission' => 'can_view_acl_user',
              'children' => 
              array (
              ),
            ),
          ),
        ),
        9 => 
        array (
          'name' => 'Settings',
          'route' => 'admin.settings.index',
          'icon' => 'ni ni-settings text-primary',
          'key' => 'admin/settings',
          'permission' => 'can_view_settings',
          'children' => 
          array (
          ),
        ),
      ),
    ),
    'portal_navbar' => 
    array (
      'items' => 
      array (
        0 => 
        array (
          'name' => 'Home',
          'route' => 'portal.home',
          'key' => 'portal/home',
          'children' => 
          array (
          ),
        ),
        1 => 
        array (
          'name' => 'Deals',
          'route' => NULL,
          'key' => 'portal/deals',
          'children' => 
          array (
          ),
        ),
        2 => 
        array (
          'name' => 'Properties',
          'route' => 'portal.properties.index',
          'key' => 'portal/properties',
          'children' => 
          array (
          ),
        ),
        3 => 
        array (
          'name' => 'Support',
          'route' => NULL,
          'key' => 'portal/support',
          'children' => 
          array (
          ),
        ),
      ),
    ),
    'allowedMediaType' => 
    array (
      0 => 'image',
      1 => 'video',
      2 => 'pdf',
    ),
    'allowedFileExtensionToUpload' => 
    array (
      'image' => 
      array (
        0 => 'jpeg',
        1 => 'jpg',
        2 => 'png',
        3 => 'svg',
      ),
      'video' => 
      array (
        0 => 'mp4',
      ),
      'pdf' => 
      array (
        0 => 'pdf',
      ),
    ),
    'allowedMediaRole' => 
    array (
      0 => 'other',
      1 => 'profile_image',
      2 => 'city_image',
      3 => 'place_image',
      4 => 'place_icon',
      5 => 'facility_icon',
      6 => 'surrounding_icon',
      7 => 'property_icon',
      8 => 'property_image',
      9 => 'room_icon',
      10 => 'room_image',
      11 => 'bed_icon',
      12 => 'bed_image',
      13 => 'gallery_image',
      14 => 'primary_image',
      15 => 'review_icon',
      16 => 'property_logo',
      17 => 'property_gallery_image',
    ),
    'settings' => 
    array (
      'valueType' => 
      array (
        0 => 'text',
        1 => 'image',
        2 => 'video',
        3 => 'bool',
      ),
      'entries' => 
      array (
        0 => 
        array (
          'key' => 'app_name',
          'value' => 'Rate Locker',
          'value_type' => 'text',
          'group' => 'app',
          'admin_only' => true,
          'is_deletable' => false,
        ),
        1 => 
        array (
          'key' => 'app_version',
          'value' => '1',
          'value_type' => 'text',
          'group' => 'app',
          'admin_only' => true,
          'is_deletable' => false,
        ),
        2 => 
        array (
          'key' => 'app_debug',
          'value' => '1',
          'value_type' => 'bool',
          'group' => 'app',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        3 => 
        array (
          'key' => 'locale',
          'value' => 'en-GB',
          'value_type' => 'text',
          'group' => 'app',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        4 => 
        array (
          'key' => 'time_zone',
          'value' => 'Asia/Dhaka',
          'value_type' => 'text',
          'group' => 'app',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        5 => 
        array (
          'key' => 'currency',
          'value' => 'GBP',
          'value_type' => 'text',
          'group' => 'app',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        6 => 
        array (
          'key' => 'currency_symbol',
          'value' => '£',
          'value_type' => 'text',
          'group' => 'app',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        7 => 
        array (
          'key' => 'date_format',
          'value' => 'DD-MMM-YYYY',
          'value_type' => 'text',
          'group' => 'app',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        8 => 
        array (
          'key' => 'country_code',
          'value' => '+88',
          'value_type' => 'text',
          'group' => 'app',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        9 => 
        array (
          'key' => 'address',
          'value' => '96-98 The Broadway, Sunderland SR4 8NX',
          'value_type' => 'text',
          'group' => 'address',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        10 => 
        array (
          'key' => 'city',
          'value' => 'Sylhet',
          'value_type' => 'text',
          'group' => 'address',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        11 => 
        array (
          'key' => 'state',
          'value' => 'Sylhet',
          'value_type' => 'text',
          'group' => 'address',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        12 => 
        array (
          'key' => 'postcode',
          'value' => 'Sylhet-3100',
          'value_type' => 'text',
          'group' => 'address',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        13 => 
        array (
          'key' => 'latitude',
          'value' => '54.894032',
          'value_type' => 'text',
          'group' => 'address',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        14 => 
        array (
          'key' => 'longitude',
          'value' => '-1.433804',
          'value_type' => 'text',
          'group' => 'address',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        15 => 
        array (
          'key' => 'ios_app_url',
          'value' => 'https://ekta-kichu.com',
          'value_type' => 'text',
          'group' => 'social',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        16 => 
        array (
          'key' => 'android_app_url',
          'value' => 'https://ekta-kichu.com',
          'value_type' => 'text',
          'group' => 'social',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        17 => 
        array (
          'key' => 'twitter_url',
          'value' => 'https://ekta-kichu.com',
          'value_type' => 'text',
          'group' => 'social',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        18 => 
        array (
          'key' => 'tumblr_url',
          'value' => 'https://ekta-kichu.com',
          'value_type' => 'text',
          'group' => 'social',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        19 => 
        array (
          'key' => 'linkedin_url',
          'value' => 'https://ekta-kichu.com',
          'value_type' => 'text',
          'group' => 'social',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        20 => 
        array (
          'key' => 'instagram_url',
          'value' => 'https://ekta-kichu.com',
          'value_type' => 'text',
          'group' => 'social',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        21 => 
        array (
          'key' => 'pinterest_url',
          'value' => 'https://ekta-kichu.com',
          'value_type' => 'text',
          'group' => 'social',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        22 => 
        array (
          'key' => 'facebook_url',
          'value' => 'https://ekta-kichu.com',
          'value_type' => 'text',
          'group' => 'social',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        23 => 
        array (
          'key' => 'trip_advisor',
          'value' => 'https://ekta-kichu.com',
          'value_type' => 'text',
          'group' => 'social',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        24 => 
        array (
          'key' => 'email',
          'value' => 'admin@company.com',
          'value_type' => 'text',
          'group' => 'contact',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        25 => 
        array (
          'key' => 'phone',
          'value' => '01719894414',
          'value_type' => 'text',
          'group' => 'contact',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        26 => 
        array (
          'key' => 'fax',
          'value' => '01712345678',
          'value_type' => 'text',
          'group' => 'contact',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        27 => 
        array (
          'key' => 'landline',
          'value' => '01712345678',
          'value_type' => 'text',
          'group' => 'contact',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        28 => 
        array (
          'key' => 'maintenance_mode',
          'value' => 0,
          'value_type' => 'bool',
          'group' => 'maintenance',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        29 => 
        array (
          'key' => 'maintenance_text',
          'value' => 'We are currently under maintenance. Please check back later.',
          'value_type' => 'text',
          'group' => 'maintenance',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        30 => 
        array (
          'key' => 'site_title',
          'value' => 'Rate Locker',
          'value_type' => 'text',
          'group' => 'site',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        31 => 
        array (
          'key' => 'site_language',
          'value' => 'en-US',
          'value_type' => 'text',
          'group' => 'site',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        32 => 
        array (
          'key' => 'home_page_title',
          'value' => 'Plan Your Dream Trip In <span>Budget</span>',
          'value_type' => 'text',
          'group' => 'site',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        33 => 
        array (
          'key' => 'home_page_subtitle',
          'value' => 'We are here to help you to find the best place to stay in your budget',
          'value_type' => 'text',
          'group' => 'site',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        34 => 
        array (
          'key' => 'home_page_number_of_slider',
          'value' => 3,
          'value_type' => 'text',
          'group' => 'site',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        35 => 
        array (
          'key' => 'site_tip_title',
          'value' => 'Hotel Booking Within Your Budget Is Never <span>Easier</span>',
          'value_type' => 'text',
          'group' => 'site',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        36 => 
        array (
          'key' => 'site_tip_description',
          'value' => 'Pickup your phone today, and install our mobile app. After that, just one click away to find your dream hotel to your destination within your budget',
          'value_type' => 'text',
          'group' => 'site',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        37 => 
        array (
          'key' => 'site_tip_image',
          'value' => 'sample/tip.jpg',
          'value_type' => 'image',
          'group' => 'site',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        38 => 
        array (
          'key' => 'mobile_app_qr_code',
          'value' => 'sample/qr-code.png',
          'value_type' => 'image',
          'group' => 'site',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        39 => 
        array (
          'key' => 'site_logo',
          'value' => 'sample/logo-big.jpg',
          'value_type' => 'image',
          'group' => 'site',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        40 => 
        array (
          'key' => 'site_logo_small',
          'value' => 'sample/logo-big.jpg',
          'value_type' => 'image',
          'group' => 'site',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        41 => 
        array (
          'key' => 'site_logo_large',
          'value' => 'sample/logo-big.jpg',
          'value_type' => 'image',
          'group' => 'site',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        42 => 
        array (
          'key' => 'favicon',
          'value' => '',
          'value_type' => 'image',
          'group' => 'site',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        43 => 
        array (
          'key' => 'designed_by',
          'value' => 'Infinity Flame Soft',
          'value_type' => 'text',
          'group' => 'footer',
          'admin_only' => false,
          'is_deletable' => false,
        ),
        44 => 
        array (
          'key' => 'copyright_text',
          'value' => 'copyright &copy; 2021 || All right reserved by ',
          'value_type' => 'text',
          'group' => 'footer',
          'admin_only' => false,
          'is_deletable' => false,
        ),
      ),
    ),
    'adminGroup' => 'Administrator',
    'hotelOwnerGroup' => 'Vendor',
  ),
  'site_configs' => 
  array (
    'allowed_facility_for' => 
    array (
      0 => 'Room',
      1 => 'Property',
    ),
    'allowed_property_class' => 
    array (
      0 => '7 Stars',
      1 => '6 Stars',
      2 => '5 Stars',
      3 => '4 Stars',
      4 => '3 Stars',
      5 => '2 Stars',
      6 => '1 Star',
      7 => 'Unrated',
    ),
    'allowed_property_status' => 
    array (
      0 => 'Pending',
      1 => 'Published',
      2 => 'Unpublished',
    ),
    'allowed_offer_for' => 
    array (
      0 => 'General',
      1 => 'Request',
    ),
    'allowed_offer_status' => 
    array (
      0 => 'Pending',
      1 => 'Negotiate',
      2 => 'Canceled',
      3 => 'Accepted',
    ),
    'allowed_booking_status' => 
    array (
      0 => 'Pending',
      1 => 'Done',
      2 => 'Timeout',
      3 => 'Approved',
      4 => 'Counter',
    ),
    'allowed_booking_offer_status' => 
    array (
      0 => 'Pending',
      1 => 'Accepted',
    ),
  ),
  'site_permissions' => 
  array (
    'PERMISSION_LIST' => 
    array (
      'CUSTOMER' => 
      array (
        0 => 
        array (
          'name' => 'View Customer',
          'slug' => 'can_view_customer',
          'subject' => 'customer',
          'permission_type' => 'global',
        ),
        1 => 
        array (
          'name' => 'Create Customer',
          'slug' => 'can_create_customer',
          'subject' => 'customer',
          'permission_type' => 'global',
        ),
      ),
      'CONTACT' => 
      array (
        0 => 
        array (
          'name' => 'View Contact',
          'slug' => 'can_view_contact',
          'subject' => 'contact',
          'permission_type' => 'global',
        ),
      ),
      'BED_TYPE' => 
      array (
        0 => 
        array (
          'name' => 'View Property Bed Type',
          'slug' => 'can_view_property_bed_type',
          'subject' => 'bed_type',
          'permission_type' => 'property',
        ),
        1 => 
        array (
          'name' => 'Create Property Bed Type',
          'slug' => 'can_create_property_bed_type',
          'subject' => 'bed_type',
          'permission_type' => 'property',
        ),
        2 => 
        array (
          'name' => 'Update Property Bed Type',
          'slug' => 'can_update_property_bed_type',
          'subject' => 'bed_type',
          'permission_type' => 'property',
        ),
        3 => 
        array (
          'name' => 'Delete Property Bed Type',
          'slug' => 'can_delete_property_bed_type',
          'subject' => 'bed_type',
          'permission_type' => 'property',
        ),
      ),
      'BOOKING' => 
      array (
        0 => 
        array (
          'name' => 'View Booking',
          'slug' => 'can_view_booking',
          'subject' => 'booking',
          'permission_type' => 'property',
        ),
        1 => 
        array (
          'name' => 'Create Booking',
          'slug' => 'can_create_booking',
          'subject' => 'booking',
          'permission_type' => 'property',
        ),
        2 => 
        array (
          'name' => 'Update Booking',
          'slug' => 'can_update_booking',
          'subject' => 'booking',
          'permission_type' => 'property',
        ),
        3 => 
        array (
          'name' => 'Delete Booking',
          'slug' => 'can_delete_booking',
          'subject' => 'booking',
          'permission_type' => 'property',
        ),
      ),
      'BOOKING_REQUEST' => 
      array (
        0 => 
        array (
          'name' => 'View Booking Request',
          'slug' => 'can_view_booking_request',
          'subject' => 'booking_request',
          'permission_type' => 'property',
        ),
        1 => 
        array (
          'name' => 'Create Booking Request',
          'slug' => 'can_create_booking_request',
          'subject' => 'booking_request',
          'permission_type' => 'property',
        ),
        2 => 
        array (
          'name' => 'Update Booking Request',
          'slug' => 'can_update_booking_request',
          'subject' => 'booking_request',
          'permission_type' => 'property',
        ),
        3 => 
        array (
          'name' => 'Delete Booking Request',
          'slug' => 'can_delete_booking_request',
          'subject' => 'booking_request',
          'permission_type' => 'property',
        ),
      ),
      'ROOM' => 
      array (
        0 => 
        array (
          'name' => 'View Room',
          'slug' => 'can_view_room',
          'subject' => 'room',
          'permission_type' => 'global',
        ),
        1 => 
        array (
          'name' => 'Create Room',
          'slug' => 'can_create_room',
          'subject' => 'room',
          'permission_type' => 'global',
        ),
        2 => 
        array (
          'name' => 'Update Room',
          'slug' => 'can_update_room',
          'subject' => 'room',
          'permission_type' => 'global',
        ),
        3 => 
        array (
          'name' => 'Delete Room',
          'slug' => 'can_delete_room',
          'subject' => 'room',
          'permission_type' => 'global',
        ),
        4 => 
        array (
          'name' => 'View Property Room',
          'slug' => 'can_view_property_room',
          'subject' => 'room',
          'permission_type' => 'property',
        ),
        5 => 
        array (
          'name' => 'Create Property Room',
          'slug' => 'can_create_property_room',
          'subject' => 'room',
          'permission_type' => 'property',
        ),
        6 => 
        array (
          'name' => 'Update Property Room',
          'slug' => 'can_update_property_room',
          'subject' => 'room',
          'permission_type' => 'property',
        ),
        7 => 
        array (
          'name' => 'Delete Property Room',
          'slug' => 'can_delete_property_room',
          'subject' => 'room',
          'permission_type' => 'property',
        ),
      ),
      'ROOM_TYPE' => 
      array (
        0 => 
        array (
          'name' => 'View Property Room Type',
          'slug' => 'can_view_property_room_type',
          'subject' => 'room_type',
          'permission_type' => 'property',
        ),
        1 => 
        array (
          'name' => 'Create Property Room Type',
          'slug' => 'can_create_property_room_type',
          'subject' => 'room_type',
          'permission_type' => 'property',
        ),
        2 => 
        array (
          'name' => 'Update Property Room Type',
          'slug' => 'can_update_property_room_type',
          'subject' => 'room_type',
          'permission_type' => 'property',
        ),
        3 => 
        array (
          'name' => 'Delete Property Room Type',
          'slug' => 'can_delete_property_room_type',
          'subject' => 'room_type',
          'permission_type' => 'property',
        ),
      ),
      'PRICE_TYPE' => 
      array (
        0 => 
        array (
          'name' => 'View Property Price Type',
          'slug' => 'can_view_property_price_type',
          'subject' => 'price_type',
          'permission_type' => 'property',
        ),
        1 => 
        array (
          'name' => 'Create Property Price Type',
          'slug' => 'can_create_property_price_type',
          'subject' => 'price_type',
          'permission_type' => 'property',
        ),
        2 => 
        array (
          'name' => 'Update Property Price Type',
          'slug' => 'can_update_property_price_type',
          'subject' => 'price_type',
          'permission_type' => 'property',
        ),
        3 => 
        array (
          'name' => 'Delete Property Price Type',
          'slug' => 'can_delete_property_price_type',
          'subject' => 'price_type',
          'permission_type' => 'property',
        ),
      ),
      'OFFER' => 
      array (
        0 => 
        array (
          'name' => 'View Property Offer',
          'slug' => 'can_view_property_offer',
          'subject' => 'offer',
          'permission_type' => 'property',
        ),
        1 => 
        array (
          'name' => 'Create Property Offer',
          'slug' => 'can_create_property_offer',
          'subject' => 'offer',
          'permission_type' => 'property',
        ),
        2 => 
        array (
          'name' => 'Update Property Offer',
          'slug' => 'can_update_property_offer',
          'subject' => 'offer',
          'permission_type' => 'property',
        ),
        3 => 
        array (
          'name' => 'Delete Property Offer',
          'slug' => 'can_delete_property_offer',
          'subject' => 'offer',
          'permission_type' => 'property',
        ),
      ),
      'REVIEW_CATEGORY' => 
      array (
        0 => 
        array (
          'name' => 'View Property Review Category',
          'slug' => 'can_view_property_review_category',
          'subject' => 'review_category',
          'permission_type' => 'property',
        ),
        1 => 
        array (
          'name' => 'Create Property Review Category',
          'slug' => 'can_create_property_review_category',
          'subject' => 'review_category',
          'permission_type' => 'property',
        ),
        2 => 
        array (
          'name' => 'Update Property Review Category',
          'slug' => 'can_update_property_review_category',
          'subject' => 'review_category',
          'permission_type' => 'property',
        ),
        3 => 
        array (
          'name' => 'Delete Property Review Category',
          'slug' => 'can_delete_property_review_category',
          'subject' => 'review_category',
          'permission_type' => 'property',
        ),
      ),
      'REVIEW' => 
      array (
        0 => 
        array (
          'name' => 'View Property Review',
          'slug' => 'can_view_property_review',
          'subject' => 'review',
          'permission_type' => 'property',
        ),
        1 => 
        array (
          'name' => 'Create Property Review',
          'slug' => 'can_create_property_review',
          'subject' => 'review',
          'permission_type' => 'property',
        ),
        2 => 
        array (
          'name' => 'Update Property Review',
          'slug' => 'can_update_property_review',
          'subject' => 'review',
          'permission_type' => 'property',
        ),
        3 => 
        array (
          'name' => 'Delete Property Review',
          'slug' => 'can_delete_property_review',
          'subject' => 'review',
          'permission_type' => 'property',
        ),
      ),
      'PROPERTY_CATEGORY' => 
      array (
        0 => 
        array (
          'name' => 'View Property Category',
          'slug' => 'can_view_property_category',
          'subject' => 'property_category',
          'permission_type' => 'global',
        ),
        1 => 
        array (
          'name' => 'Create Property Category',
          'slug' => 'can_create_property_category',
          'subject' => 'property_category',
          'permission_type' => 'global',
        ),
        2 => 
        array (
          'name' => 'Update Property Category',
          'slug' => 'can_update_property_category',
          'subject' => 'property_category',
          'permission_type' => 'global',
        ),
        3 => 
        array (
          'name' => 'Delete Property Category',
          'slug' => 'can_delete_property_category',
          'subject' => 'property_category',
          'permission_type' => 'global',
        ),
      ),
      'PROPERTY' => 
      array (
        0 => 
        array (
          'name' => 'View Property',
          'slug' => 'can_view_property',
          'subject' => 'property',
          'permission_type' => 'global',
        ),
        1 => 
        array (
          'name' => 'Create Property',
          'slug' => 'can_create_property',
          'subject' => 'property',
          'permission_type' => 'global',
        ),
        2 => 
        array (
          'name' => 'Update Property',
          'slug' => 'can_update_property',
          'subject' => 'property',
          'permission_type' => 'global',
        ),
        3 => 
        array (
          'name' => 'Delete Property',
          'slug' => 'can_delete_property',
          'subject' => 'property',
          'permission_type' => 'global',
        ),
      ),
      'PROPERTY_RULE' => 
      array (
        0 => 
        array (
          'name' => 'View Property Rule',
          'slug' => 'can_view_property_rule',
          'subject' => 'property_rule',
          'permission_type' => 'property',
        ),
        1 => 
        array (
          'name' => 'Create Property Rule',
          'slug' => 'can_create_property_rule',
          'subject' => 'property_rule',
          'permission_type' => 'property',
        ),
        2 => 
        array (
          'name' => 'Update Property Rule',
          'slug' => 'can_update_property_rule',
          'subject' => 'property_rule',
          'permission_type' => 'property',
        ),
        3 => 
        array (
          'name' => 'Delete Property Rule',
          'slug' => 'can_delete_property_rule',
          'subject' => 'property_rule',
          'permission_type' => 'property',
        ),
      ),
      'SURROUNDING' => 
      array (
        0 => 
        array (
          'name' => 'View Surrounding',
          'slug' => 'can_view_surrounding',
          'subject' => 'surrounding',
          'permission_type' => 'global',
        ),
        1 => 
        array (
          'name' => 'Create Surrounding',
          'slug' => 'can_create_surrounding',
          'subject' => 'surrounding',
          'permission_type' => 'global',
        ),
        2 => 
        array (
          'name' => 'Update Surrounding',
          'slug' => 'can_update_surrounding',
          'subject' => 'surrounding',
          'permission_type' => 'global',
        ),
        3 => 
        array (
          'name' => 'Delete Surrounding',
          'slug' => 'can_delete_surrounding',
          'subject' => 'surrounding',
          'permission_type' => 'global',
        ),
      ),
      'SURROUNDING_PLACE' => 
      array (
        0 => 
        array (
          'name' => 'View Surrounding Place',
          'slug' => 'can_view_surrounding_place',
          'subject' => 'surrounding_place',
          'permission_type' => 'global',
        ),
        1 => 
        array (
          'name' => 'Create Surrounding Place',
          'slug' => 'can_create_surrounding_place',
          'subject' => 'surrounding_place',
          'permission_type' => 'global',
        ),
        2 => 
        array (
          'name' => 'Update Surrounding Place',
          'slug' => 'can_update_surrounding_place',
          'subject' => 'surrounding_place',
          'permission_type' => 'global',
        ),
        3 => 
        array (
          'name' => 'Delete Surrounding Place',
          'slug' => 'can_delete_surrounding_place',
          'subject' => 'surrounding_place',
          'permission_type' => 'global',
        ),
      ),
      'FACILITY' => 
      array (
        0 => 
        array (
          'name' => 'View Property Facility',
          'slug' => 'can_view_property_facility',
          'subject' => 'facility',
          'permission_type' => 'property',
        ),
        1 => 
        array (
          'name' => 'Create Property Facility',
          'slug' => 'can_create_property_facility',
          'subject' => 'facility',
          'permission_type' => 'property',
        ),
        2 => 
        array (
          'name' => 'Update Property Facility',
          'slug' => 'can_update_property_facility',
          'subject' => 'facility',
          'permission_type' => 'property',
        ),
        3 => 
        array (
          'name' => 'Delete Facility',
          'slug' => 'can_delete_facility',
          'subject' => 'facility',
          'permission_type' => 'property',
        ),
      ),
      'SUB_FACILITY' => 
      array (
        0 => 
        array (
          'name' => 'View Property Sub Facility',
          'slug' => 'can_view_property_sub_facility',
          'subject' => 'sub_facility',
          'permission_type' => 'property',
        ),
        1 => 
        array (
          'name' => 'Create Property Sub Facility',
          'slug' => 'can_create_property_sub_facility',
          'subject' => 'sub_facility',
          'permission_type' => 'property',
        ),
        2 => 
        array (
          'name' => 'Update Sub Facility',
          'slug' => 'can_update_sub_facility',
          'subject' => 'sub_facility',
          'permission_type' => 'property',
        ),
        3 => 
        array (
          'name' => 'Delete Property Sub Facility',
          'slug' => 'can_delete_property_sub_facility',
          'subject' => 'sub_facility',
          'permission_type' => 'property',
        ),
      ),
      'COUNTRY' => 
      array (
        0 => 
        array (
          'name' => 'View Country',
          'slug' => 'can_view_country',
          'subject' => 'country',
          'permission_type' => 'global',
        ),
        1 => 
        array (
          'name' => 'Create Country',
          'slug' => 'can_create_country',
          'subject' => 'country',
          'permission_type' => 'global',
        ),
        2 => 
        array (
          'name' => 'Update Country',
          'slug' => 'can_update_country',
          'subject' => 'country',
          'permission_type' => 'global',
        ),
        3 => 
        array (
          'name' => 'Delete Country',
          'slug' => 'can_delete_country',
          'subject' => 'country',
          'permission_type' => 'global',
        ),
      ),
      'STATE' => 
      array (
        0 => 
        array (
          'name' => 'View State',
          'slug' => 'can_view_state',
          'subject' => 'state',
          'permission_type' => 'global',
        ),
        1 => 
        array (
          'name' => 'Create State',
          'slug' => 'can_create_state',
          'subject' => 'state',
          'permission_type' => 'global',
        ),
        2 => 
        array (
          'name' => 'Update State',
          'slug' => 'can_update_state',
          'subject' => 'state',
          'permission_type' => 'global',
        ),
        3 => 
        array (
          'name' => 'Delete State',
          'slug' => 'can_delete_state',
          'subject' => 'state',
          'permission_type' => 'global',
        ),
      ),
      'CITY' => 
      array (
        0 => 
        array (
          'name' => 'View City',
          'slug' => 'can_view_city',
          'subject' => 'city',
          'permission_type' => 'global',
        ),
        1 => 
        array (
          'name' => 'Create City',
          'slug' => 'can_create_city',
          'subject' => 'city',
          'permission_type' => 'global',
        ),
        2 => 
        array (
          'name' => 'Update City',
          'slug' => 'can_update_city',
          'subject' => 'city',
          'permission_type' => 'global',
        ),
        3 => 
        array (
          'name' => 'Delete City',
          'slug' => 'can_delete_city',
          'subject' => 'city',
          'permission_type' => 'global',
        ),
      ),
      'PLACE' => 
      array (
        0 => 
        array (
          'name' => 'View Place',
          'slug' => 'can_view_place',
          'subject' => 'place',
          'permission_type' => 'global',
        ),
        1 => 
        array (
          'name' => 'Create Place',
          'slug' => 'can_create_place',
          'subject' => 'place',
          'permission_type' => 'global',
        ),
        2 => 
        array (
          'name' => 'Update Place',
          'slug' => 'can_update_place',
          'subject' => 'place',
          'permission_type' => 'global',
        ),
        3 => 
        array (
          'name' => 'Delete Place',
          'slug' => 'can_delete_place',
          'subject' => 'place',
          'permission_type' => 'global',
        ),
      ),
      'PROPERTY_SETTING' => 
      array (
        0 => 
        array (
          'name' => 'View Property Setting',
          'slug' => 'can_view_property_setting',
          'subject' => 'place',
          'permission_type' => 'global',
        ),
        1 => 
        array (
          'name' => 'Create Property Setting',
          'slug' => 'can_create_property_setting',
          'subject' => 'place',
          'permission_type' => 'global',
        ),
        2 => 
        array (
          'name' => 'Update Property Setting',
          'slug' => 'can_update_property_setting',
          'subject' => 'place',
          'permission_type' => 'global',
        ),
        3 => 
        array (
          'name' => 'Delete PProperty Setting',
          'slug' => 'can_delete_property_setting',
          'subject' => 'place',
          'permission_type' => 'global',
        ),
      ),
      'ACL_GROUP' => 
      array (
        0 => 
        array (
          'name' => 'View Role',
          'slug' => 'can_view_acl_role',
          'subject' => 'ACL',
          'permission_type' => 'global',
        ),
        1 => 
        array (
          'name' => 'Create Role',
          'slug' => 'can_create_acl_role',
          'subject' => 'ACL',
          'permission_type' => 'global',
        ),
        2 => 
        array (
          'name' => 'Update Role',
          'slug' => 'can_update_acl_role',
          'subject' => 'ACL',
          'permission_type' => 'global',
        ),
        3 => 
        array (
          'name' => 'Delete Role',
          'slug' => 'can_delete_acl_role',
          'subject' => 'ACL',
          'permission_type' => 'global',
        ),
        4 => 
        array (
          'name' => 'View Property ACL Role',
          'slug' => 'can_view_property_acl_role',
          'subject' => 'ACL',
          'permission_type' => 'property',
        ),
        5 => 
        array (
          'name' => 'Create Property ACL Role',
          'slug' => 'can_create_property_acl_role',
          'subject' => 'ACL',
          'permission_type' => 'property',
        ),
        6 => 
        array (
          'name' => 'Update Property ACL Role',
          'slug' => 'can_update_property_acl_role',
          'subject' => 'ACL',
          'permission_type' => 'property',
        ),
        7 => 
        array (
          'name' => 'Delete Property ACL Role',
          'slug' => 'can_delete_property_acl_role',
          'subject' => 'ACL',
          'permission_type' => 'property',
        ),
      ),
      'ACL_PERMISSION' => 
      array (
        0 => 
        array (
          'name' => 'View Permission',
          'slug' => 'can_view_acl_permission',
          'subject' => 'ACL',
          'permission_type' => 'global',
        ),
        1 => 
        array (
          'name' => 'Create Permission',
          'slug' => 'can_create_acl_permission',
          'subject' => 'permission',
          'permission_type' => 'global',
        ),
        2 => 
        array (
          'name' => 'Update Permission',
          'slug' => 'can_update_acl_permission',
          'subject' => 'permission',
          'permission_type' => 'global',
        ),
        3 => 
        array (
          'name' => 'Delete Permission',
          'slug' => 'can_delete_acl_permission',
          'subject' => 'permission',
          'permission_type' => 'global',
        ),
        4 => 
        array (
          'name' => 'View Property ACL Permission',
          'slug' => 'can_view_property_acl_permission',
          'subject' => 'ACL',
          'permission_type' => 'property',
        ),
        5 => 
        array (
          'name' => 'Create Property ACL Permission',
          'slug' => 'can_create_property_acl_permission',
          'subject' => 'ACL',
          'permission_type' => 'property',
        ),
        6 => 
        array (
          'name' => 'Update Property ACL Permission',
          'slug' => 'can_update_property_acl_permission',
          'subject' => 'ACL',
          'permission_type' => 'property',
        ),
        7 => 
        array (
          'name' => 'Delete Property ACL Permission',
          'slug' => 'can_delete_property_acl_permission',
          'subject' => 'ACL',
          'permission_type' => 'property',
        ),
      ),
      'ACL_USER' => 
      array (
        0 => 
        array (
          'name' => 'View Acl User',
          'slug' => 'can_view_acl_user',
          'subject' => 'ACL',
          'permission_type' => 'global',
        ),
        1 => 
        array (
          'name' => 'Create ACL User',
          'slug' => 'can_create_acl_user',
          'subject' => 'user',
          'permission_type' => 'global',
        ),
        2 => 
        array (
          'name' => 'Update ACL User',
          'slug' => 'can_update_acl_user',
          'subject' => 'ACL',
          'permission_type' => 'global',
        ),
        3 => 
        array (
          'name' => 'Delete ACL User',
          'slug' => 'can_delete_acl_user',
          'subject' => 'ACL',
          'permission_type' => 'global',
        ),
        4 => 
        array (
          'name' => 'View Property ACL User',
          'slug' => 'can_view_property_acl_user',
          'subject' => 'ACL',
          'permission_type' => 'property',
        ),
        5 => 
        array (
          'name' => 'Create Property ACL User',
          'slug' => 'can_create_property_acl_user',
          'subject' => 'user',
          'permission_type' => 'property',
        ),
        6 => 
        array (
          'name' => 'Update Property ACL User',
          'slug' => 'can_update_property_acl_user',
          'subject' => 'ACL',
          'permission_type' => 'property',
        ),
        7 => 
        array (
          'name' => 'Delete Property ACL User',
          'slug' => 'can_delete_property_acl_user',
          'subject' => 'ACL',
          'permission_type' => 'property',
        ),
      ),
      'MISC' => 
      array (
        0 => 
        array (
          'name' => 'Login To Admin',
          'slug' => 'can_login_to_admin',
          'subject' => 'misc',
          'permission_type' => 'global',
        ),
        1 => 
        array (
          'name' => 'View Dashboard',
          'slug' => 'can_view_property_dashboard',
          'subject' => 'ACL',
          'permission_type' => 'global',
        ),
        2 => 
        array (
          'name' => 'View Property Dashboard',
          'slug' => 'can_view_property_dashboard',
          'subject' => 'ACL',
          'permission_type' => 'property',
        ),
        3 => 
        array (
          'name' => 'View ACL',
          'slug' => 'can_view_acl',
          'subject' => 'misc',
          'permission_type' => 'global',
        ),
        4 => 
        array (
          'name' => 'View Property Rooms',
          'slug' => 'can_view_property_rooms',
          'subject' => 'misc',
          'permission_type' => 'property',
        ),
        5 => 
        array (
          'name' => 'View Properties',
          'slug' => 'can_view_properties',
          'subject' => 'misc',
          'permission_type' => 'global',
        ),
        6 => 
        array (
          'name' => 'View Locations',
          'slug' => 'can_view_locations',
          'subject' => 'misc',
          'permission_type' => 'global',
        ),
        7 => 
        array (
          'name' => 'View Property Facilities',
          'slug' => 'can_view_property_facilities',
          'subject' => 'misc',
          'permission_type' => 'property',
        ),
        8 => 
        array (
          'name' => 'View Surroundings',
          'slug' => 'can_view_surroundings',
          'subject' => 'misc',
          'permission_type' => 'global',
        ),
        9 => 
        array (
          'name' => 'View Settings',
          'slug' => 'can_view_settings',
          'subject' => 'misc',
          'permission_type' => 'global',
        ),
        10 => 
        array (
          'name' => 'View Property Settings',
          'slug' => 'can_view_property_settings',
          'subject' => 'misc',
          'permission_type' => 'global',
        ),
        11 => 
        array (
          'name' => 'View Reviews',
          'slug' => 'can_view_reviews',
          'subject' => 'misc',
          'permission_type' => 'global',
        ),
        12 => 
        array (
          'name' => 'View Offers',
          'slug' => 'can_view_offers',
          'subject' => 'misc',
          'permission_type' => 'property',
        ),
      ),
    ),
    'PERMISSION_NAMES' => 
    array (
      'CAN_VIEW_COUNTRY' => 'can_view_country',
      'CAN_VIEW_CUSTOMER' => 'can_view_customer',
      'CAN_CREATE_CUSTOMER' => 'can_create_customer',
      'CAN_UPDATE_CUSTOMER' => 'can_update_customer',
      'CAN_DELETE_CUSTOMER' => 'can_delete_customer',
      'CAN_VIEW_CATEGORY' => 'can_view_category',
      'CAN_CREATE_CATEGORY' => 'can_create_category',
      'CAN_UPDATE_CATEGORY' => 'can_update_category',
      'CAN_DELETE_CATEGORY' => 'can_delete_category',
      'CAN_VIEW_ACL_ROLE' => 'can_view_acl_role',
      'CAN_CREATE_ACL_ROLE' => 'can_create_acl_role',
      'CAN_UPDATE_ACL_ROLE' => 'can_update_acl_role',
      'CAN_DELETE_ACL_ROLE' => 'can_delete_acl_role',
      'CAN_VIEW_ACL_PERMISSION' => 'can_view_acl_permission',
      'CAN_CREATE_ACL_PERMISSION' => 'can_create_acl_permission',
      'CAN_UPDATE_ACL_PERMISSION' => 'can_update_acl_permission',
      'CAN_DELETE_ACL_PERMISSION' => 'can_delete_acl_permission',
      'CAN_UPDATE_USER_GROUP' => 'can_update_user_group',
      'CAN_VIEW_ACL_USER' => 'can_view_acl_user',
      'CAN_CREATE_ACL_USER' => 'can_create_acl_user',
      'CAN_UPDATE_ACL_USER' => 'can_update_acl_user',
      'CAN_DELETE_ACL_USER' => 'can_delete_acl_user',
      'CAN_VIEW_SETTINGS' => 'can_view_settings',
      'CAN_VIEW_DASHBOARD' => 'can_view_dashboard',
      'CAN_VIEW_ACL' => 'can_view_acl',
      'CAN_VIEW_LOCATIONS' => 'can_view_locations',
      'CAN_VIEW_FACILITIES' => 'can_view_facilities',
      'CAN_VIEW_CONTACT' => 'can_view_contact',
      'CAN_LOGIN_TO_ADMIN' => 'can_login_to_admin',
    ),
  ),
  'sslcommerz' => 
  array (
    'apiCredentials' => 
    array (
      'store_id' => NULL,
      'store_password' => NULL,
    ),
    'apiUrl' => 
    array (
      'make_payment' => '/gwprocess/v4/api.php',
      'transaction_status' => '/validator/api/merchantTransIDvalidationAPI.php',
      'order_validate' => '/validator/api/validationserverAPI.php',
      'refund_payment' => '/validator/api/merchantTransIDvalidationAPI.php',
      'refund_status' => '/validator/api/merchantTransIDvalidationAPI.php',
    ),
    'apiDomain' => 'https://securepay.sslcommerz.com',
    'connect_from_localhost' => false,
    'success_url' => '/success',
    'failed_url' => '/fail',
    'cancel_url' => '/cancel',
    'ipn_url' => '/ipn',
  ),
  'telescope' => 
  array (
    'enabled' => true,
    'domain' => NULL,
    'path' => 'telescope',
    'driver' => 'database',
    'storage' => 
    array (
      'database' => 
      array (
        'connection' => 'mysql',
        'chunk' => 1000,
      ),
    ),
    'queue' => 
    array (
      'connection' => NULL,
      'queue' => NULL,
    ),
    'middleware' => 
    array (
      0 => 'web',
      1 => 'Laravel\\Telescope\\Http\\Middleware\\Authorize',
    ),
    'only_paths' => 
    array (
    ),
    'ignore_paths' => 
    array (
      0 => 'livewire*',
      1 => 'nova-api*',
      2 => 'pulse*',
    ),
    'ignore_commands' => 
    array (
    ),
    'watchers' => 
    array (
      'Laravel\\Telescope\\Watchers\\BatchWatcher' => true,
      'Laravel\\Telescope\\Watchers\\CacheWatcher' => 
      array (
        'enabled' => true,
        'hidden' => 
        array (
        ),
      ),
      'Laravel\\Telescope\\Watchers\\ClientRequestWatcher' => true,
      'Laravel\\Telescope\\Watchers\\CommandWatcher' => 
      array (
        'enabled' => true,
        'ignore' => 
        array (
        ),
      ),
      'Laravel\\Telescope\\Watchers\\DumpWatcher' => 
      array (
        'enabled' => true,
        'always' => false,
      ),
      'Laravel\\Telescope\\Watchers\\EventWatcher' => 
      array (
        'enabled' => true,
        'ignore' => 
        array (
        ),
      ),
      'Laravel\\Telescope\\Watchers\\ExceptionWatcher' => true,
      'Laravel\\Telescope\\Watchers\\GateWatcher' => 
      array (
        'enabled' => true,
        'ignore_abilities' => 
        array (
        ),
        'ignore_packages' => true,
        'ignore_paths' => 
        array (
        ),
      ),
      'Laravel\\Telescope\\Watchers\\JobWatcher' => true,
      'Laravel\\Telescope\\Watchers\\LogWatcher' => 
      array (
        'enabled' => true,
        'level' => 'error',
      ),
      'Laravel\\Telescope\\Watchers\\MailWatcher' => true,
      'Laravel\\Telescope\\Watchers\\ModelWatcher' => 
      array (
        'enabled' => true,
        'events' => 
        array (
          0 => 'eloquent.*',
        ),
        'hydrations' => true,
      ),
      'Laravel\\Telescope\\Watchers\\NotificationWatcher' => true,
      'Laravel\\Telescope\\Watchers\\QueryWatcher' => 
      array (
        'enabled' => true,
        'ignore_packages' => true,
        'ignore_paths' => 
        array (
        ),
        'slow' => 100,
      ),
      'Laravel\\Telescope\\Watchers\\RedisWatcher' => true,
      'Laravel\\Telescope\\Watchers\\RequestWatcher' => 
      array (
        'enabled' => true,
        'size_limit' => 64,
        'ignore_http_methods' => 
        array (
        ),
        'ignore_status_codes' => 
        array (
        ),
      ),
      'Laravel\\Telescope\\Watchers\\ScheduleWatcher' => true,
      'Laravel\\Telescope\\Watchers\\ViewWatcher' => true,
    ),
  ),
  'webpush' => 
  array (
    'vapid' => 
    array (
      'subject' => 'mailto:hello@oystay.com',
      'public_key' => 'BI62ECoAZ3XRhC4NJE0k1lQk78khgnR-zbksNXpQP0DHF5M3KbDA8pyMSKwVRaF6EjpnQA2LksbBwShe4xtUSF0',
      'private_key' => 'tSFxB9wxeLJGcquzz--w5hykMBgZkFyNFSvtqBHrWAk',
      'pem_file' => NULL,
    ),
    'model' => 'NotificationChannels\\WebPush\\PushSubscription',
    'table_name' => 'push_subscriptions',
    'database_connection' => 'mysql',
    'client_options' => 
    array (
    ),
    'automatic_padding' => true,
  ),
  'activitylog' => 
  array (
    'enabled' => true,
    'delete_records_older_than_days' => 365,
    'default_log_name' => 'default',
    'default_auth_driver' => NULL,
    'subject_returns_soft_deleted_models' => false,
    'activity_model' => 'Spatie\\Activitylog\\Models\\Activity',
    'table_name' => 'activity_log',
    'database_connection' => NULL,
  ),
  'flare' => 
  array (
    'key' => NULL,
    'flare_middleware' => 
    array (
      0 => 'Spatie\\FlareClient\\FlareMiddleware\\RemoveRequestIp',
      1 => 'Spatie\\FlareClient\\FlareMiddleware\\AddGitInformation',
      2 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddNotifierName',
      3 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddEnvironmentInformation',
      4 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddExceptionInformation',
      5 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddDumps',
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddLogs' => 
      array (
        'maximum_number_of_collected_logs' => 200,
      ),
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddQueries' => 
      array (
        'maximum_number_of_collected_queries' => 200,
        'report_query_bindings' => true,
      ),
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddJobs' => 
      array (
        'max_chained_job_reporting_depth' => 5,
      ),
      6 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddContext',
      7 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddExceptionHandledStatus',
      'Spatie\\FlareClient\\FlareMiddleware\\CensorRequestBodyFields' => 
      array (
        'censor_fields' => 
        array (
          0 => 'password',
          1 => 'password_confirmation',
        ),
      ),
      'Spatie\\FlareClient\\FlareMiddleware\\CensorRequestHeaders' => 
      array (
        'headers' => 
        array (
          0 => 'API-KEY',
          1 => 'Authorization',
          2 => 'Cookie',
          3 => 'Set-Cookie',
          4 => 'X-CSRF-TOKEN',
          5 => 'X-XSRF-TOKEN',
        ),
      ),
    ),
    'send_logs_as_events' => true,
  ),
  'ignition' => 
  array (
    'editor' => 'phpstorm',
    'theme' => 'auto',
    'enable_share_button' => true,
    'register_commands' => false,
    'solution_providers' => 
    array (
      0 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\BadMethodCallSolutionProvider',
      1 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\MergeConflictSolutionProvider',
      2 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\UndefinedPropertySolutionProvider',
      3 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\IncorrectValetDbCredentialsSolutionProvider',
      4 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingAppKeySolutionProvider',
      5 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\DefaultDbNameSolutionProvider',
      6 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\TableNotFoundSolutionProvider',
      7 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingImportSolutionProvider',
      8 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\InvalidRouteActionSolutionProvider',
      9 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\ViewNotFoundSolutionProvider',
      10 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\RunningLaravelDuskInProductionProvider',
      11 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingColumnSolutionProvider',
      12 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UnknownValidationSolutionProvider',
      13 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingMixManifestSolutionProvider',
      14 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingViteManifestSolutionProvider',
      15 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingLivewireComponentSolutionProvider',
      16 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UndefinedViewVariableSolutionProvider',
      17 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\GenericLaravelExceptionSolutionProvider',
      18 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\OpenAiSolutionProvider',
      19 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\SailNetworkSolutionProvider',
      20 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UnknownMysql8CollationSolutionProvider',
      21 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UnknownMariadbCollationSolutionProvider',
    ),
    'ignored_solution_providers' => 
    array (
    ),
    'enable_runnable_solutions' => NULL,
    'remote_sites_path' => '/Volumes/Development/projects/oystay/hotel-booking',
    'local_sites_path' => '',
    'housekeeping_endpoint_prefix' => '_ignition',
    'settings_file_path' => '',
    'recorders' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\Recorders\\DumpRecorder\\DumpRecorder',
      1 => 'Spatie\\LaravelIgnition\\Recorders\\JobRecorder\\JobRecorder',
      2 => 'Spatie\\LaravelIgnition\\Recorders\\LogRecorder\\LogRecorder',
      3 => 'Spatie\\LaravelIgnition\\Recorders\\QueryRecorder\\QueryRecorder',
    ),
    'open_ai_key' => NULL,
    'with_stack_frame_arguments' => true,
    'argument_reducers' => 
    array (
      0 => 'Spatie\\Backtrace\\Arguments\\Reducers\\BaseTypeArgumentReducer',
      1 => 'Spatie\\Backtrace\\Arguments\\Reducers\\ArrayArgumentReducer',
      2 => 'Spatie\\Backtrace\\Arguments\\Reducers\\StdClassArgumentReducer',
      3 => 'Spatie\\Backtrace\\Arguments\\Reducers\\EnumArgumentReducer',
      4 => 'Spatie\\Backtrace\\Arguments\\Reducers\\ClosureArgumentReducer',
      5 => 'Spatie\\Backtrace\\Arguments\\Reducers\\DateTimeArgumentReducer',
      6 => 'Spatie\\Backtrace\\Arguments\\Reducers\\DateTimeZoneArgumentReducer',
      7 => 'Spatie\\Backtrace\\Arguments\\Reducers\\SymphonyRequestArgumentReducer',
      8 => 'Spatie\\LaravelIgnition\\ArgumentReducers\\ModelArgumentReducer',
      9 => 'Spatie\\LaravelIgnition\\ArgumentReducers\\CollectionArgumentReducer',
      10 => 'Spatie\\Backtrace\\Arguments\\Reducers\\StringableArgumentReducer',
    ),
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
    'trust_project' => 'always',
  ),
);
